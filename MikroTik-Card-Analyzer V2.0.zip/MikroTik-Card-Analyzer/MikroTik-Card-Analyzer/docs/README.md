# MikroTik Card Analyzer v2.0

A comprehensive local tool for analyzing MikroTik hotspot cards, understanding creation patterns, and testing authentication settings in authorized test environments.

## Features

- **Multi-format Import**: TXT, CSV, XLSX support with automatic format detection
- **Pattern Analysis**: Statistical analysis of card patterns, prefixes, suffixes, and relationships
- **Synthetic Generator**: Seed-based reproducible test data generation
- **Login Page Inspector**: Analyze MikroTik login page structure
- **Authentication Lab**: Safe testing environment with rate limiting and circuit breakers
- **Professional Reports**: PDF, Excel, CSV, JSON export capabilities
- **Dark Dashboard**: Modern RTL/LTR responsive interface

## Installation

### Prerequisites

- Python 3.9 or higher
- pip (Python package manager)

### Setup

1. **Clone or download the project**

2. **Install dependencies**
```bash
   pip install -r requirements.txt
```

3. **Run the application**
   
   **Windows:**
```bash
   run.bat
```
   
   **Linux/macOS:**
```bash
   chmod +x run.sh
   ./run.sh
```

4. **Access the application**
   
   Open your browser and navigate to: `http://127.0.0.1:8000`

## Usage

### 1. Import Cards

- Navigate to "استيراد الكروت" (Import Cards)
- Drag and drop files or click to select
- Supported formats: TXT, CSV, XLSX
- Expected CSV format: `username,password,type`

### 2. Analyze Patterns

- Navigate to "تحليل الأنماط" (Pattern Analysis)
- Click "بدء التحليل" (Start Analysis)
- View statistical breakdowns and charts

### 3. Generate Test Data

- Navigate to "المولد الاصطناعي" (Synthetic Generator)
- Configure generation parameters
- Use seed for reproducible results
- Export generated data

### 4. Inspect Login Pages

- Navigate to "فحص صفحات الدخول" (Login Page Inspector)
- Enter URL of test login page
- View form structure and authentication mode

### 5. Test Authentication

- Navigate to "مختبر المصادقة" (Authentication Lab)
- Enter test credentials and target URL
- View test results and session logs

### 6. Export Reports

- Navigate to "التقارير" (Reports)
- Select export format (PDF, Excel, CSV, JSON)
- Download generated reports

## Project Structure
