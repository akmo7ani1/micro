"""
Core smoke tests for MikroTik Card Analyzer
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.database.connection import init_db, SessionLocal
from backend.models.card import Card
from backend.services.import_service import ImportService
from backend.analyzers.pattern_analyzer import PatternAnalyzer
from backend.generators.synthetic_generator import SyntheticGenerator


def test_database_initialization():
    """Test database initialization."""
    print("Testing database initialization...")
    init_db()
    db = SessionLocal()
    try:
        # Check if tables exist
        card_count = db.query(Card).count()
        print(f"✓ Database initialized. Cards in DB: {card_count}")
    finally:
        db.close()


def test_pattern_analyzer():
    """Test pattern analyzer with sample data."""
    print("\nTesting pattern analyzer...")
    db = SessionLocal()
    try:
        # Add sample cards
        sample_cards = [
            Card(username="user001", password="pass123", card_type="test"),
            Card(username="user002", password="pass456", card_type="test"),
            Card(username="admin01", password="admin123", card_type="test"),
        ]
        db.add_all(sample_cards)
        db.commit()

        # Analyze
        analyzer = PatternAnalyzer(db)
        results = analyzer.analyze_all()

        print(f"✓ Analysis complete:")
        print(f"  - Total cards: {results.get('total_cards', 0)}")
        print(f"  - Username analysis: {'username_analysis' in results}")
        print(f"  - Pattern analysis: {'pattern_analysis' in results}")

        # Clean up
        db.query(Card).filter(Card.card_type == "test").delete()
        db.commit()
    finally:
        db.close()


def test_synthetic_generator():
    """Test synthetic generator."""
    print("\nTesting synthetic generator...")
    
    generator = SyntheticGenerator(seed=42)
    credentials = generator.generate_batch(
        count=10,
        username_length=8,
        password_length=6,
        prefix="TEST",
    )

    print(f"✓ Generated {len(credentials)} credentials")
    print(f"  - Sample: {credentials[0]}")
    
    # Test reproducibility
    generator2 = SyntheticGenerator(seed=42)
    credentials2 = generator2.generate_batch(
        count=10,
        username_length=8,
        password_length=6,
        prefix="TEST",
    )

    assert credentials[0]['username'] == credentials2[0]['username'], "Seed reproducibility failed"
    print("✓ Seed reproducibility verified")


def test_import_service():
    """Test import service with sample CSV."""
    print("\nTesting import service...")
    db = SessionLocal()
    try:
        # Create sample CSV
        sample_csv = "data/imports/test_sample.csv"
        os.makedirs(os.path.dirname(sample_csv), exist_ok=True)
        
        with open(sample_csv, 'w') as f:
            f.write("username,password,type\n")
            f.write("testuser1,testpass1,imported\n")
            f.write("testuser2,testpass2,imported\n")

        # Import
        service = ImportService(db)
        result = service.import_file(sample_csv)

        print(f"✓ Imported {result['imported_count']} cards")
        print(f"  - Batch ID: {result['batch_id']}")

        # Clean up
        db.query(Card).filter(Card.batch_id == result['batch_id']).delete()
        db.commit()
        os.remove(sample_csv)
    finally:
        db.close()


if __name__ == "__main__":
    print("=" * 60)
    print("MIKROTIK CARD ANALYZER - CORE TESTS")
    print("=" * 60)

    try:
        test_database_initialization()
        test_pattern_analyzer()
        test_synthetic_generator()
        test_import_service()

        print("\n" + "=" * 60)
        print("✓ ALL TESTS PASSED")
        print("=" * 60)
    except Exception as e:
        print(f"\n✗ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
