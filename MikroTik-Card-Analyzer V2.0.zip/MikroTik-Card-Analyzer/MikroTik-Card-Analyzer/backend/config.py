"""
Centralized configuration loader.
Reads config.json and exposes typed accessors.
"""
import json
import os
from pathlib import Path
from typing import Any, Dict


class Config:
    _instance = None
    _data: Dict[str, Any] = {}
    _root: Path

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._load()
        return cls._instance

    def _load(self) -> None:
        # Resolve project root: backend/.. -> MikroTik-Card-Analyzer/
        self._root = Path(__file__).resolve().parent.parent
        config_path = self._root / "config.json"

        defaults = {
            "app_name": "MikroTik Card Analyzer",
            "version": "2.0.0",
            "host": "127.0.0.1",
            "port": 8000,
            "database": {
                "path": "data/mikrotik_analyzer.db"
            },
            "import": {
                "max_file_size_mb": 50,
                "allowed_extensions": [".txt", ".csv", ".xlsx", ".xls"]
            },
            "authentication_lab": {
                "default_delay_ms": 500,
                "max_retries": 3,
                "circuit_breaker_threshold": 10,
                "timeout_seconds": 10
            },
            "generator": {
                "default_seed": 42
            },
            "reports": {
                "output_dir": "data/exports"
            },
            "ui": {
                "default_language": "ar",
                "default_direction": "rtl"
            }
        }

        if config_path.exists():
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    user_data = json.load(f)
                self._data = self._deep_merge(defaults, user_data)
            except (json.JSONDecodeError, OSError):
                self._data = defaults
        else:
            self._data = defaults
            # Persist defaults so user can edit
            try:
                config_path.parent.mkdir(parents=True, exist_ok=True)
                with open(config_path, "w", encoding="utf-8") as f:
                    json.dump(defaults, f, indent=4, ensure_ascii=False)
            except OSError:
                pass

        # Ensure data directories exist
        for sub in ("imports", "exports", "backups"):
            (self._root / "data" / sub).mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _deep_merge(base: Dict, override: Dict) -> Dict:
        result = base.copy()
        for k, v in override.items():
            if k in result and isinstance(result[k], dict) and isinstance(v, dict):
                result[k] = Config._deep_merge(result[k], v)
            else:
                result[k] = v
        return result

    def get(self, key: str, default: Any = None) -> Any:
        """Dot-notation accessor: config.get('database.path')"""
        parts = key.split(".")
        node = self._data
        for p in parts:
            if isinstance(node, dict) and p in node:
                node = node[p]
            else:
                return default
        return node

    @property
    def root(self) -> Path:
        return self._root

    @property
    def db_path(self) -> Path:
        rel = self.get("database.path", "data/mikrotik_analyzer.db")
        return self._root / rel

    @property
    def exports_dir(self) -> Path:
        rel = self.get("reports.output_dir", "data/exports")
        return self._root / rel

    def to_dict(self) -> Dict[str, Any]:
        return json.loads(json.dumps(self._data))


config = Config()
