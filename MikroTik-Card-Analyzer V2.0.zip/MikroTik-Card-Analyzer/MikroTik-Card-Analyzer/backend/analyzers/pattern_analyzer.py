"""
Statistical pattern analysis engine.
Analyzes card patterns including lengths, prefixes, suffixes, character distributions,
and relationships between username and password fields.
"""
import re
from collections import Counter, defaultdict
from typing import List, Dict, Tuple

from sqlalchemy.orm import Session

from backend.models.card import Card


class PatternAnalyzer:
    """Analyzes patterns in imported card data."""

    def __init__(self, db: Session):
        self.db = db

    def analyze_all(self, batch_id: str = None) -> Dict:
        """
        Perform comprehensive pattern analysis on cards.
        
        Args:
            batch_id: Optional batch ID to filter cards
            
        Returns:
            Dict containing all analysis results
        """
        query = self.db.query(Card)
        if batch_id:
            query = query.filter(Card.batch_id == batch_id)

        cards = query.all()

        if not cards:
            return {"error": "no_cards_found", "message": "No cards available for analysis"}

        results = {
            "total_cards": len(cards),
            "username_analysis": self._analyze_usernames(cards),
            "password_analysis": self._analyze_passwords(cards),
            "pattern_analysis": self._analyze_patterns(cards),
            "relationship_analysis": self._analyze_relationships(cards),
            "batch_comparison": self._compare_batches() if not batch_id else {},
        }

        return results

    def _analyze_usernames(self, cards: List[Card]) -> Dict:
        """Analyze username patterns."""
        usernames = [c.username for c in cards if c.username]

        if not usernames:
            return {}

        lengths = [len(u) for u in usernames]
        prefixes = [u[:3] for u in usernames if len(u) >= 3]
        suffixes = [u[-3:] for u in usernames if len(u) >= 3]

        # Extract numeric suffixes
        numeric_suffixes = []
        for u in usernames:
            nums = re.findall(r'\d+$', u)
            if nums:
                numeric_suffixes.append(nums[0])

        # Character type analysis
        alpha_only = sum(1 for u in usernames if u.isalpha())
        numeric_only = sum(1 for u in usernames if u.isdigit())
        alphanumeric = sum(1 for u in usernames if u.isalnum() and not u.isalpha() and not u.isdigit())

        return {
            "length_stats": {
                "min": min(lengths),
                "max": max(lengths),
                "avg": round(sum(lengths) / len(lengths), 2),
                "median": self._median(lengths),
            },
            "length_distribution": dict(Counter(lengths)),
            "common_prefixes": dict(Counter(prefixes).most_common(10)),
            "common_suffixes": dict(Counter(suffixes).most_common(10)),
            "numeric_suffixes": dict(Counter(numeric_suffixes).most_common(10)),
            "character_types": {
                "alpha_only": alpha_only,
                "numeric_only": numeric_only,
                "alphanumeric": alphanumeric,
            },
        }

    def _analyze_passwords(self, cards: List[Card]) -> Dict:
        """Analyze password patterns."""
        passwords = [c.password for c in cards if c.password]

        if not passwords:
            return {"has_passwords": False}

        lengths = [len(p) for p in passwords]

        # Character type analysis
        alpha_only = sum(1 for p in passwords if p.isalpha())
        numeric_only = sum(1 for p in passwords if p.isdigit())
        alphanumeric = sum(1 for p in passwords if p.isalnum() and not p.isalpha() and not p.isdigit())
        has_special = sum(1 for p in passwords if not p.isalnum())

        return {
            "has_passwords": True,
            "total_with_password": len(passwords),
            "length_stats": {
                "min": min(lengths),
                "max": max(lengths),
                "avg": round(sum(lengths) / len(lengths), 2),
                "median": self._median(lengths),
            },
            "length_distribution": dict(Counter(lengths)),
            "character_types": {
                "alpha_only": alpha_only,
                "numeric_only": numeric_only,
                "alphanumeric": alphanumeric,
                "has_special_chars": has_special,
            },
        }

    def _analyze_patterns(self, cards: List[Card]) -> Dict:
        """Detect common patterns and templates."""
        patterns = defaultdict(int)

        for card in cards:
            u = card.username
            if not u:
                continue

            # Detect pattern: prefix + numbers
            match = re.match(r'^([A-Za-z]+)(\d+)$', u)
            if match:
                prefix = match.group(1)
                pattern = f"{prefix}_NUMERIC"
                patterns[pattern] += 1
            else:
                # Detect pattern: numbers only
                if u.isdigit():
                    patterns["NUMERIC_ONLY"] += 1
                # Detect pattern: letters only
                elif u.isalpha():
                    patterns["ALPHA_ONLY"] += 1
                else:
                    patterns["MIXED"] += 1

        # Calculate confidence
        total = sum(patterns.values())
        pattern_confidence = {
            pattern: {
                "count": count,
                "percentage": round((count / total) * 100, 2) if total > 0 else 0,
                "confidence": "high" if count / total > 0.7 else "medium" if count / total > 0.3 else "low"
            }
            for pattern, count in patterns.items()
        }

        return {
            "detected_patterns": pattern_confidence,
            "most_common_pattern": max(patterns.items(), key=lambda x: x[1])[0] if patterns else None,
        }

    def _analyze_relationships(self, cards: List[Card]) -> Dict:
        """Analyze relationships between username and password."""
        relationships = {
            "username_equals_password": 0,
            "password_is_username_reversed": 0,
            "password_contains_username": 0,
            "same_length": 0,
            "different_length": 0,
        }

        for card in cards:
            if not card.username or not card.password:
                continue

            u = card.username
            p = card.password

            if u == p:
                relationships["username_equals_password"] += 1
            elif u == p[::-1]:
                relationships["password_is_username_reversed"] += 1
            elif u in p or p in u:
                relationships["password_contains_username"] += 1

            if len(u) == len(p):
                relationships["same_length"] += 1
            else:
                relationships["different_length"] += 1

        return relationships

    def _compare_batches(self) -> Dict:
        """Compare patterns across different batches."""
        batches = self.db.query(Card.batch_id).distinct().all()
        batches = [b[0] for b in batches if b[0]]

        if len(batches) < 2:
            return {"message": "Need at least 2 batches for comparison"}

        batch_stats = {}
        for batch_id in batches:
            cards = self.db.query(Card).filter(Card.batch_id == batch_id).all()
            if cards:
                usernames = [c.username for c in cards if c.username]
                lengths = [len(u) for u in usernames]
                batch_stats[batch_id] = {
                    "count": len(cards),
                    "avg_length": round(sum(lengths) / len(lengths), 2) if lengths else 0,
                    "min_length": min(lengths) if lengths else 0,
                    "max_length": max(lengths) if lengths else 0,
                }

        return batch_stats

    @staticmethod
    def _median(data: List[int]) -> float:
        """Calculate median of a list."""
        if not data:
            return 0
        sorted_data = sorted(data)
        n = len(sorted_data)
        mid = n // 2
        if n % 2 == 0:
            return (sorted_data[mid - 1] + sorted_data[mid]) / 2
        else:
            return sorted_data[mid]
