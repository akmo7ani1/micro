"""
Settings router: handles application configuration and activity logs.
"""
from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy import func

from backend.database.connection import get_db
from backend.models.activity_log import ActivityLog
from backend.config import config


router = APIRouter()


class UpdateSettingsRequest(BaseModel):
    """Request model for updating settings."""
    settings: dict


@router.get("/")
def get_settings():
    """
    Get current application settings.
    """
    return {
        "success": True,
        "settings": config.to_dict(),
    }


@router.put("/")
def update_settings(request: UpdateSettingsRequest):
    """
    Update application settings.
    
    Note: Settings are updated in-memory only.
    To persist changes, update config.json manually.
    """
    # Update in-memory config
    for key, value in request.settings.items():
        config._data[key] = value

    return {
        "success": True,
        "message": "Settings updated (in-memory only)",
        "settings": config.to_dict(),
    }


@router.get("/logs")
def get_activity_logs(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=1000),
    action: str = Query(None),
    db: Session = Depends(get_db),
):
    """
    Get activity logs with pagination and optional filtering.
    """
    query = db.query(ActivityLog)
    
    if action:
        query = query.filter(ActivityLog.action == action)

    total = query.count()
    logs = query.order_by(ActivityLog.created_at.desc()).offset((page - 1) * page_size).limit(page_size).all()

    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "logs": [log.to_dict() for log in logs],
    }


@router.get("/logs/stats")
def get_log_stats(db: Session = Depends(get_db)):
    """
    Get activity log statistics.
    """
    total = db.query(func.count(ActivityLog.id)).scalar()
    
    action_counts = (
        db.query(ActivityLog.action, func.count(ActivityLog.id))
        .group_by(ActivityLog.action)
        .all()
    )

    status_counts = (
        db.query(ActivityLog.status, func.count(ActivityLog.id))
        .group_by(ActivityLog.status)
        .all()
    )

    return {
        "total_logs": total,
        "by_action": {action: count for action, count in action_counts},
        "by_status": {status: count for status, count in status_counts},
    }


@router.delete("/logs")
def clear_activity_logs(db: Session = Depends(get_db)):
    """
    Clear all activity logs.
    """
    db.query(ActivityLog).delete()
    db.commit()

    return {
        "success": True,
        "message": "All activity logs cleared",
    }


@router.get("/system-info")
def get_system_info():
    """
    Get system information.
    """
    import platform
    import sys

    return {
        "app_name": config.get("app_name"),
        "version": config.get("version"),
        "python_version": sys.version,
        "platform": platform.platform(),
        "database_path": str(config.db_path),
        "exports_directory": str(config.exports_dir),
    }
