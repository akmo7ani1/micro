"""
Reports router: handles report generation and export.
"""
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from backend.database.connection import get_db
from backend.services.export_service import ExportService
from backend.analyzers.pattern_analyzer import PatternAnalyzer
from backend.reports.pdf_reporter import PDFReporter
from backend.reports.excel_reporter import ExcelReporter


router = APIRouter()


@router.get("/export/cards/csv")
def export_cards_csv(db: Session = Depends(get_db)):
    """
    Export all cards to CSV format.
    """
    try:
        service = ExportService(db)
        filepath = service.export_cards_csv()

        return FileResponse(
            path=filepath,
            filename=filepath.split("/")[-1],
            media_type="text/csv",
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")


@router.get("/export/cards/excel")
def export_cards_excel(db: Session = Depends(get_db)):
    """
    Export all cards to Excel format.
    """
    try:
        service = ExportService(db)
        filepath = service.export_cards_excel()

        return FileResponse(
            path=filepath,
            filename=filepath.split("/")[-1],
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")


@router.get("/export/cards/json")
def export_cards_json(db: Session = Depends(get_db)):
    """
    Export all cards to JSON format.
    """
    try:
        service = ExportService(db)
        filepath = service.export_cards_json()

        return FileResponse(
            path=filepath,
            filename=filepath.split("/")[-1],
            media_type="application/json",
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")


@router.get("/export/analysis/pdf")
def export_analysis_pdf(db: Session = Depends(get_db)):
    """
    Export analysis report to PDF format.
    """
    try:
        analyzer = PatternAnalyzer(db)
        analysis_data = analyzer.analyze_all()

        reporter = PDFReporter()
        filepath = reporter.generate_analysis_report(analysis_data)

        return FileResponse(
            path=filepath,
            filename=filepath.split("/")[-1],
            media_type="application/pdf",
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF generation failed: {str(e)}")


@router.get("/export/analysis/excel")
def export_analysis_excel(db: Session = Depends(get_db)):
    """
    Export analysis report to Excel format.
    """
    try:
        analyzer = PatternAnalyzer(db)
        analysis_data = analyzer.analyze_all()

        reporter = ExcelReporter()
        filepath = reporter.generate_analysis_report(analysis_data)

        return FileResponse(
            path=filepath,
            filename=filepath.split("/")[-1],
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Excel generation failed: {str(e)}")


@router.get("/export/sessions/csv")
def export_sessions_csv(db: Session = Depends(get_db)):
    """
    Export test sessions to CSV format.
    """
    try:
        service = ExportService(db)
        filepath = service.export_test_sessions_csv()

        return FileResponse(
            path=filepath,
            filename=filepath.split("/")[-1],
            media_type="text/csv",
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")


@router.get("/history")
def get_export_history(db: Session = Depends(get_db)):
    """
    List all exported files.
    """
    try:
        service = ExportService(db)
        history = service.get_export_history()

        return {
            "files": history,
            "total": len(history),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve history: {str(e)}")
