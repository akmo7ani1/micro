"""
Inspector router: analyzes MikroTik login page structure.
"""
import re
from typing import Optional

import httpx
from bs4 import BeautifulSoup
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, HttpUrl

from backend.models.activity_log import ActivityLog
from backend.database.connection import get_db
from sqlalchemy.orm import Session
from fastapi import Depends


router = APIRouter()


class InspectRequest(BaseModel):
    """Request model for login page inspection."""
    url: str
    timeout: int = 10


@router.post("/inspect")
async def inspect_login_page(
    request: InspectRequest,
    db: Session = Depends(get_db),
):
    """
    Analyze a MikroTik login page structure.
    
    Extracts:
    - Form action and method
    - Input fields (username, password, hidden)
    - Submit buttons
    - JavaScript dependencies
    - Redirect behavior
    """
    try:
        async with httpx.AsyncClient(timeout=request.timeout, follow_redirects=True) as client:
            response = await client.get(request.url)
            response.raise_for_status()

        html = response.text
        soup = BeautifulSoup(html, "html.parser")

        # Extract forms
        forms = []
        for form in soup.find_all("form"):
            form_data = {
                "action": form.get("action", ""),
                "method": form.get("method", "GET").upper(),
                "id": form.get("id"),
                "class": form.get("class"),
                "inputs": [],
                "buttons": [],
            }

            # Extract inputs
            for inp in form.find_all("input"):
                input_data = {
                    "type": inp.get("type", "text"),
                    "name": inp.get("name"),
                    "id": inp.get("id"),
                    "value": inp.get("value"),
                    "placeholder": inp.get("placeholder"),
                    "required": inp.has_attr("required"),
                }
                form_data["inputs"].append(input_data)

            # Extract buttons
            for button in form.find_all(["button", "input"]):
                if button.name == "button" or button.get("type") == "submit":
                    button_data = {
                        "type": button.get("type", "submit"),
                        "text": button.get_text(strip=True) or button.get("value"),
                        "id": button.get("id"),
                        "class": button.get("class"),
                    }
                    form_data["buttons"].append(button_data)

            forms.append(form_data)

        # Detect authentication mode
        auth_mode = detect_auth_mode(forms)

        # Extract scripts
        scripts = [
            {"src": s.get("src"), "inline": bool(s.string)}
            for s in soup.find_all("script")
        ]

        # Detect redirects
        redirects = []
        for meta in soup.find_all("meta"):
            if meta.get("http-equiv", "").lower() == "refresh":
                content = meta.get("content", "")
                if "url=" in content.lower():
                    url = content.split("url=")[-1].strip()
                    redirects.append(url)

        result = {
            "url": request.url,
            "status_code": response.status_code,
            "final_url": str(response.url),
            "forms": forms,
            "auth_mode": auth_mode,
            "scripts": scripts,
            "redirects": redirects,
            "has_javascript": len(scripts) > 0,
        }

        # Log activity
        log = ActivityLog(
            action="inspect_page",
            target=request.url,
            details=f"Inspected login page, detected {auth_mode} mode",
            status="success",
        )
        db.add(log)
        db.commit()

        return {
            "success": True,
            "data": result,
        }

    except httpx.TimeoutException:
        raise HTTPException(status_code=408, detail="Request timeout")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"HTTP error: {e}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Inspection failed: {str(e)}")


def detect_auth_mode(forms: list) -> str:
    """
    Detect authentication mode based on form structure.
    
    Returns:
    - "username_only": Only username field
    - "username_password": Both username and password fields
    - "custom": Custom or complex form
    - "unknown": Cannot determine
    """
    for form in forms:
        input_types = [inp["type"].lower() for inp in form["inputs"]]
        input_names = [inp["name"].lower() if inp["name"] else "" for inp in form["inputs"]]

        has_username = any(
            "user" in name or "login" in name or "name" in name
            for name in input_names
        )
        has_password = "password" in input_types

        if has_username and has_password:
            return "username_password"
        elif has_username and not has_password:
            return "username_only"

    return "unknown"


@router.get("/detect-mode")
async def detect_authentication_mode(url: str):
    """
    Quick detection of authentication mode without full inspection.
    """
    try:
        async with httpx.AsyncClient(timeout=10, follow_redirects=True) as client:
            response = await client.get(url)
            response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")
        forms = soup.find_all("form")

        # Simple detection
        for form in forms:
            inputs = form.find_all("input")
            types = [inp.get("type", "text").lower() for inp in inputs]

            if "password" in types:
                return {"mode": "username_password", "has_password_field": True}
            elif any("text" in t for t in types):
                return {"mode": "username_only", "has_password_field": False}

        return {"mode": "unknown", "has_password_field": False}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Detection failed: {str(e)}")
