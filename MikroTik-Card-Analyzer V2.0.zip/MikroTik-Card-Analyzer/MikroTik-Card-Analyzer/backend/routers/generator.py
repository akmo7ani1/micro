"""
Generator router: handles synthetic credential generation.
"""
from typing import Optional

from fastapi import APIRouter, Depends, Query, HTTPException
from pydantic import BaseModel

from backend.generators.synthetic_generator import SyntheticGenerator
from backend.models.activity_log import ActivityLog
from backend.database.connection import get_db
from sqlalchemy.orm import Session


router = APIRouter()


class GenerateRequest(BaseModel):
    """Request model for credential generation."""
    count: int = 100
    username_length: int = 8
    password_length: int = 6
    prefix: str = ""
    suffix: str = ""
    username_chars: str = "alphanumeric"
    password_chars: str = "alphanumeric"
    include_password: bool = True
    seed: Optional[int] = None


class GenerateFromPatternRequest(BaseModel):
    """Request model for pattern-based generation."""
    pattern: str
    count: int = 100
    include_password: bool = True
    password_length: int = 6
    seed: Optional[int] = None


@router.post("/generate")
def generate_credentials(request: GenerateRequest):
    """
    Generate synthetic credentials with specified parameters.
    """
    try:
        generator = SyntheticGenerator(seed=request.seed)
        credentials = generator.generate_batch(
            count=request.count,
            username_length=request.username_length,
            password_length=request.password_length,
            prefix=request.prefix,
            suffix=request.suffix,
            username_chars=request.username_chars,
            password_chars=request.password_chars,
            include_password=request.include_password,
        )

        return {
            "success": True,
            "count": len(credentials),
            "seed": request.seed,
            "credentials": credentials,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")


@router.post("/generate-from-pattern")
def generate_from_pattern(request: GenerateFromPatternRequest):
    """
    Generate credentials based on a pattern template.
    
    Pattern syntax:
    - {A} = random letter
    - {N} = random digit
    - {X} = random alphanumeric
    - Fixed text is preserved
    """
    try:
        generator = SyntheticGenerator(seed=request.seed)
        credentials = generator.generate_from_pattern(
            pattern=request.pattern,
            count=request.count,
            include_password=request.include_password,
            password_length=request.password_length,
        )

        return {
            "success": True,
            "count": len(credentials),
            "pattern": request.pattern,
            "seed": request.seed,
            "credentials": credentials,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")


@router.post("/compare-with-sample")
def compare_with_sample(
    request: GenerateRequest,
    sample_usernames: list[str],
    db: Session = Depends(get_db),
):
    """
    Generate credentials and compare with a sample set.
    """
    try:
        generator = SyntheticGenerator(seed=request.seed)
        credentials = generator.generate_batch(
            count=request.count,
            username_length=request.username_length,
            password_length=request.password_length,
            prefix=request.prefix,
            suffix=request.suffix,
            username_chars=request.username_chars,
            password_chars=request.password_chars,
            include_password=request.include_password,
        )

        comparison = generator.compare_with_sample(credentials, sample_usernames)

        return {
            "success": True,
            "generated_count": len(credentials),
            "sample_count": len(sample_usernames),
            "comparison": comparison,
            "sample_credentials": credentials[:10],  # Return first 10 as sample
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Comparison failed: {str(e)}")


@router.get("/charsets")
def list_charsets():
    """
    List available character sets for generation.
    """
    return {
        "charsets": {
            "alpha": "Letters only (a-z, A-Z)",
            "numeric": "Digits only (0-9)",
            "alphanumeric": "Letters and digits",
            "all": "Letters, digits, and special characters",
        }
    }
