"""
Authentication Lab router: manages test sessions and authentication testing.
"""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy import func

from backend.database.connection import get_db
from backend.models.test_account import TestAccount
from backend.models.test_session import TestSession
from backend.models.activity_log import ActivityLog
from backend.authentication_lab.session_manager import SessionManager
from backend.authentication_lab.rate_limiter import RateLimiter


router = APIRouter()


class CreateTestAccountRequest(BaseModel):
    """Request model for creating test accounts."""
    username: str
    password: Optional[str] = None
    auth_mode: str = "username_password"
    is_valid: bool = True
    notes: Optional[str] = None


class TestAuthRequest(BaseModel):
    """Request model for testing authentication."""
    target_url: str
    username: str
    password: Optional[str] = None
    auth_mode: str = "username_password"
    timeout: int = 10


@router.post("/accounts")
def create_test_account(
    request: CreateTestAccountRequest,
    db: Session = Depends(get_db),
):
    """
    Create a test account for authentication testing.
    """
    account = TestAccount(
        username=request.username,
        password=request.password,
        auth_mode=request.auth_mode,
        is_valid=request.is_valid,
        notes=request.notes,
    )
    db.add(account)
    db.commit()
    db.refresh(account)

    return {
        "success": True,
        "message": "Test account created",
        "account": account.to_dict(),
    }


@router.get("/accounts")
def list_test_accounts(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=1000),
    db: Session = Depends(get_db),
):
    """
    List all test accounts with pagination.
    """
    query = db.query(TestAccount)
    total = query.count()
    accounts = query.offset((page - 1) * page_size).limit(page_size).all()

    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "accounts": [acc.to_dict() for acc in accounts],
    }


@router.delete("/accounts/{account_id}")
def delete_test_account(account_id: int, db: Session = Depends(get_db)):
    """
    Delete a test account.
    """
    account = db.query(TestAccount).filter(TestAccount.id == account_id).first()
    
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    db.delete(account)
    db.commit()

    return {
        "success": True,
        "message": f"Deleted test account {account_id}",
    }


@router.post("/test")
async def test_authentication(
    request: TestAuthRequest,
    db: Session = Depends(get_db),
):
    """
    Test authentication against a target URL.
    
    This endpoint:
    - Validates rate limits
    - Performs authentication test
    - Logs the session
    - Returns result
    """
    # Check rate limit
    limiter = RateLimiter()
    if not limiter.can_proceed():
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded. Please wait before testing again."
        )

    try:
        manager = SessionManager(db)
        result = await manager.test_authentication(
            target_url=request.target_url,
            username=request.username,
            password=request.password,
            auth_mode=request.auth_mode,
            timeout=request.timeout,
        )

        # Record rate limit hit
        limiter.record_attempt()

        return {
            "success": True,
            "result": result,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Test failed: {str(e)}")


@router.get("/sessions")
def list_test_sessions(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=1000),
    success_only: Optional[bool] = Query(None),
    db: Session = Depends(get_db),
):
    """
    List test session logs with pagination.
    """
    query = db.query(TestSession)
    
    if success_only is not None:
        query = query.filter(TestSession.success == success_only)

    total = query.count()
    sessions = query.order_by(TestSession.created_at.desc()).offset((page - 1) * page_size).limit(page_size).all()

    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "sessions": [s.to_dict() for s in sessions],
    }


@router.get("/sessions/stats")
def get_session_stats(db: Session = Depends(get_db)):
    """
    Get test session statistics.
    """
    total = db.query(func.count(TestSession.id)).scalar()
    successful = db.query(func.count(TestSession.id)).filter(TestSession.success == True).scalar()
    failed = total - successful

    avg_response_time = db.query(func.avg(TestSession.response_time_ms)).scalar()

    return {
        "total_sessions": total,
        "successful": successful,
        "failed": failed,
        "success_rate": round((successful / total) * 100, 2) if total > 0 else 0,
        "avg_response_time_ms": round(avg_response_time, 2) if avg_response_time else 0,
    }


@router.delete("/sessions")
def clear_all_sessions(db: Session = Depends(get_db)):
    """
    Clear all test session logs.
    """
    db.query(TestSession).delete()
    db.commit()

    return {
        "success": True,
        "message": "All test sessions cleared",
    }
