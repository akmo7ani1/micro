"""Routers package initialization."""
from backend.routers import (
    cards,
    analysis,
    generator,
    inspector,
    auth_lab,
    reports,
    settings,
)

__all__ = [
    "cards",
    "analysis",
    "generator",
    "inspector",
    "auth_lab",
    "reports",
    "settings",
]