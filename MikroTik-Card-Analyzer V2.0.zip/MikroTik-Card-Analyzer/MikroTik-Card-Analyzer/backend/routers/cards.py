"""
Cards router: handles card import, listing, deletion, and batch management.
"""
import shutil
import tempfile
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, UploadFile, File, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func

from backend.database.connection import get_db
from backend.models.card import Card
from backend.models.activity_log import ActivityLog
from backend.services.import_service import ImportService
from backend.services.cleaning_service import CleaningService
from backend.config import config


router = APIRouter()


@router.post("/import")
async def import_cards(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """
    Import cards from uploaded file (TXT, CSV, XLSX).
    """
    # Validate file extension
    ext = Path(file.filename).suffix.lower()
    allowed = config.get("import.allowed_extensions", [".txt", ".csv", ".xlsx", ".xls"])
    
    if ext not in allowed:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format: {ext}. Allowed: {', '.join(allowed)}"
        )

    # Validate file size
    max_size_mb = config.get("import.max_file_size_mb", 50)
    content = await file.read()
    if len(content) > max_size_mb * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail=f"File too large. Maximum size: {max_size_mb}MB"
        )

    # Save to temporary location
    temp_dir = config.root / "data" / "imports"
    temp_dir.mkdir(parents=True, exist_ok=True)
    temp_path = temp_dir / file.filename

    try:
        with open(temp_path, "wb") as f:
            f.write(content)

        # Import using service
        service = ImportService(db)
        result = service.import_file(str(temp_path))

        return {
            "success": True,
            "message": f"Successfully imported {result['imported_count']} cards",
            "data": result,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Import failed: {str(e)}")

    finally:
        # Clean up temporary file
        if temp_path.exists():
            temp_path.unlink()


@router.get("/")
def list_cards(
    batch_id: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=1000),
    db: Session = Depends(get_db),
):
    """
    List cards with pagination and optional batch filtering.
    """
    query = db.query(Card)
    
    if batch_id:
        query = query.filter(Card.batch_id == batch_id)

    total = query.count()
    cards = query.offset((page - 1) * page_size).limit(page_size).all()

    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size,
        "cards": [card.to_dict() for card in cards],
    }


@router.get("/batches")
def list_batches(db: Session = Depends(get_db)):
    """
    List all import batches with statistics.
    """
    batches = (
        db.query(
            Card.batch_id,
            Card.source_file,
            func.count(Card.id).label("card_count"),
            func.min(Card.created_at).label("imported_at"),
        )
        .group_by(Card.batch_id, Card.source_file)
        .order_by(func.min(Card.created_at).desc())
        .all()
    )

    return {
        "batches": [
            {
                "batch_id": b.batch_id,
                "source_file": b.source_file,
                "card_count": b.card_count,
                "imported_at": b.imported_at.isoformat() if b.imported_at else None,
            }
            for b in batches
        ]
    }


@router.delete("/batch/{batch_id}")
def delete_batch(batch_id: str, db: Session = Depends(get_db)):
    """
    Delete all cards in a specific batch.
    """
    cards = db.query(Card).filter(Card.batch_id == batch_id).all()
    count = len(cards)

    if count == 0:
        raise HTTPException(status_code=404, detail="Batch not found")

    for card in cards:
        db.delete(card)

    db.commit()

    # Log activity
    log = ActivityLog(
        action="delete_batch",
        target=batch_id,
        details=f"Deleted {count} cards from batch",
        status="success",
    )
    db.add(log)
    db.commit()

    return {
        "success": True,
        "message": f"Deleted {count} cards from batch {batch_id}",
    }


@router.delete("/{card_id}")
def delete_card(card_id: int, db: Session = Depends(get_db)):
    """
    Delete a single card by ID.
    """
    card = db.query(Card).filter(Card.id == card_id).first()
    
    if not card:
        raise HTTPException(status_code=404, detail="Card not found")

    db.delete(card)
    db.commit()

    return {
        "success": True,
        "message": f"Deleted card {card_id}",
    }


@router.post("/clean")
def clean_data(db: Session = Depends(get_db)):
    """
    Clean all card data: remove duplicates, normalize, validate.
    """
    service = CleaningService(db)
    stats = service.clean_all()

    return {
        "success": True,
        "message": "Data cleaning completed",
        "statistics": stats,
    }


@router.get("/duplicates")
def preview_duplicates(db: Session = Depends(get_db)):
    """
    Preview duplicate cards without removing them.
    """
    service = CleaningService(db)
    duplicates = service.get_duplicates_preview()

    return {
        "duplicates": duplicates,
        "total_duplicate_groups": len(duplicates),
    }


@router.get("/stats")
def get_stats(db: Session = Depends(get_db)):
    """
    Get overall card statistics.
    """
    total = db.query(func.count(Card.id)).scalar()
    with_password = db.query(func.count(Card.id)).filter(Card.password != None).scalar()
    batches = db.query(func.count(func.distinct(Card.batch_id))).scalar()

    return {
        "total_cards": total,
        "cards_with_password": with_password,
        "cards_without_password": total - with_password,
        "total_batches": batches,
    }
