"""
Analysis router: handles pattern analysis and statistical reporting.
"""
from typing import Optional

from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session

from backend.database.connection import get_db
from backend.analyzers.pattern_analyzer import PatternAnalyzer
from backend.models.activity_log import ActivityLog


router = APIRouter()


@router.get("/patterns")
def analyze_patterns(
    batch_id: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    """
    Perform comprehensive pattern analysis on cards.
    """
    try:
        analyzer = PatternAnalyzer(db)
        results = analyzer.analyze_all(batch_id=batch_id)

        # Log activity
        log = ActivityLog(
            action="analyze_patterns",
            target=batch_id or "all",
            details="Pattern analysis completed",
            status="success",
        )
        db.add(log)
        db.commit()

        return {
            "success": True,
            "data": results,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")


@router.get("/username-lengths")
def get_username_length_distribution(
    batch_id: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    """
    Get username length distribution.
    """
    analyzer = PatternAnalyzer(db)
    results = analyzer.analyze_all(batch_id=batch_id)

    if "error" in results:
        raise HTTPException(status_code=404, detail=results["message"])

    return {
        "distribution": results["username_analysis"]["length_distribution"],
        "stats": results["username_analysis"]["length_stats"],
    }


@router.get("/password-lengths")
def get_password_length_distribution(
    batch_id: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    """
    Get password length distribution.
    """
    analyzer = PatternAnalyzer(db)
    results = analyzer.analyze_all(batch_id=batch_id)

    if "error" in results:
        raise HTTPException(status_code=404, detail=results["message"])

    password_analysis = results["password_analysis"]
    if not password_analysis.get("has_passwords"):
        return {
            "has_passwords": False,
            "message": "No passwords found in dataset",
        }

    return {
        "has_passwords": True,
        "distribution": password_analysis["length_distribution"],
        "stats": password_analysis["length_stats"],
    }


@router.get("/prefixes")
def get_common_prefixes(
    batch_id: Optional[str] = Query(None),
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
):
    """
    Get most common username prefixes.
    """
    analyzer = PatternAnalyzer(db)
    results = analyzer.analyze_all(batch_id=batch_id)

    if "error" in results:
        raise HTTPException(status_code=404, detail=results["message"])

    prefixes = results["username_analysis"]["common_prefixes"]
    top_prefixes = dict(list(prefixes.items())[:limit])

    return {
        "prefixes": top_prefixes,
        "total_unique_prefixes": len(prefixes),
    }


@router.get("/patterns-detected")
def get_detected_patterns(
    batch_id: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    """
    Get detected patterns with confidence levels.
    """
    analyzer = PatternAnalyzer(db)
    results = analyzer.analyze_all(batch_id=batch_id)

    if "error" in results:
        raise HTTPException(status_code=404, detail=results["message"])

    return {
        "patterns": results["pattern_analysis"]["detected_patterns"],
        "most_common": results["pattern_analysis"]["most_common_pattern"],
    }


@router.get("/relationships")
def get_username_password_relationships(
    batch_id: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    """
    Analyze relationships between username and password fields.
    """
    analyzer = PatternAnalyzer(db)
    results = analyzer.analyze_all(batch_id=batch_id)

    if "error" in results:
        raise HTTPException(status_code=404, detail=results["message"])

    return {
        "relationships": results["relationship_analysis"],
    }


@router.get("/batch-comparison")
def compare_batches(db: Session = Depends(get_db)):
    """
    Compare patterns across different import batches.
    """
    analyzer = PatternAnalyzer(db)
    results = analyzer.analyze_all()

    if "error" in results:
        raise HTTPException(status_code=404, detail=results["message"])

    comparison = results["batch_comparison"]
    
    if "message" in comparison:
        return {
            "message": comparison["message"],
            "batches": {},
        }

    return {
        "batches": comparison,
        "total_batches": len(comparison),
    }
