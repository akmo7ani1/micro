"""
Data cleaning service.
Handles deduplication, normalization, and validation of imported cards.
"""
from typing import Dict, List, Tuple

from sqlalchemy import func
from sqlalchemy.orm import Session

from backend.models.card import Card
from backend.models.activity_log import ActivityLog


class CleaningService:
    """Handles data cleaning operations on imported cards."""

    def __init__(self, db: Session):
        self.db = db

    def clean_all(self) -> Dict:
        """
        Perform comprehensive cleaning on all cards.
        
        Returns:
            Dict with cleaning statistics
        """
        stats = {
            "total_cards": 0,
            "duplicates_removed": 0,
            "empty_removed": 0,
            "normalized": 0,
        }

        # Count total
        stats["total_cards"] = self.db.query(func.count(Card.id)).scalar()

        # Remove duplicates (keep first occurrence)
        stats["duplicates_removed"] = self._remove_duplicates()

        # Remove empty usernames
        stats["empty_removed"] = self._remove_empty_usernames()

        # Normalize data
        stats["normalized"] = self._normalize_data()

        # Log activity
        self._log_activity(
            action="clean",
            target="all_cards",
            details=f"Cleaning complete: {stats}",
            status="success"
        )

        return stats

    def _remove_duplicates(self) -> int:
        """Remove duplicate cards based on username+password combination."""
        # Find duplicates
        duplicates = (
            self.db.query(Card)
            .group_by(Card.username, Card.password)
            .having(func.count(Card.id) > 1)
            .all()
        )

        removed = 0
        seen = set()

        for card in duplicates:
            key = (card.username, card.password)
            if key in seen:
                self.db.delete(card)
                removed += 1
            else:
                seen.add(key)

        if removed > 0:
            self.db.commit()

        return removed

    def _remove_empty_usernames(self) -> int:
        """Remove cards with empty or whitespace-only usernames."""
        empty_cards = (
            self.db.query(Card)
            .filter(
                (Card.username == "") | 
                (Card.username == None) |
                (func.trim(Card.username) == "")
            )
            .all()
        )

        removed = len(empty_cards)
        for card in empty_cards:
            self.db.delete(card)

        if removed > 0:
            self.db.commit()

        return removed

    def _normalize_data(self) -> int:
        """Normalize card data (trim whitespace, standardize types)."""
        cards = self.db.query(Card).all()
        normalized = 0

        for card in cards:
            changed = False

            # Trim username
            if card.username and card.username != card.username.strip():
                card.username = card.username.strip()
                changed = True

            # Trim password
            if card.password and card.password != card.password.strip():
                card.password = card.password.strip()
                changed = True

            # Standardize card_type
            if card.card_type:
                ct = card.card_type.lower().strip()
                if ct != card.card_type:
                    card.card_type = ct
                    changed = True

            if changed:
                normalized += 1

        if normalized > 0:
            self.db.commit()

        return normalized

    def get_duplicates_preview(self) -> List[Dict]:
        """Preview duplicate cards without removing them."""
        duplicates = (
            self.db.query(
                Card.username,
                Card.password,
                func.count(Card.id).label("count")
            )
            .group_by(Card.username, Card.password)
            .having(func.count(Card.id) > 1)
            .all()
        )

        return [
            {
                "username": d.username,
                "password": d.password,
                "count": d.count,
            }
            for d in duplicates
        ]

    def _log_activity(self, action: str, target: str, details: str, status: str):
        """Log cleaning activity."""
        log = ActivityLog(
            action=action,
            target=target,
            details=details,
            status=status,
        )
        self.db.add(log)
        self.db.commit()
