"""
Multi-format file importer.
Supports TXT, CSV, XLSX with automatic format detection and validation.
"""
import csv
import io
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Tuple

import pandas as pd
from sqlalchemy.orm import Session

from backend.models.card import Card
from backend.models.activity_log import ActivityLog


class ImportService:
    """Handles importing cards from various file formats."""

    SUPPORTED_EXTENSIONS = {".txt", ".csv", ".xlsx", ".xls"}

    def __init__(self, db: Session):
        self.db = db

    def import_file(self, file_path: str, file_content: bytes = None) -> Dict:
        """
        Import cards from a file.
        
        Args:
            file_path: Path to the file (used for extension detection)
            file_content: Optional file content bytes (if file is uploaded)
            
        Returns:
            Dict with import statistics
        """
        path = Path(file_path)
        ext = path.suffix.lower()

        if ext not in self.SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported file format: {ext}")

        # Generate batch ID for this import
        batch_id = f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"

        try:
            if ext == ".txt":
                cards_data = self._parse_txt(file_content or path.read_bytes())
            elif ext == ".csv":
                cards_data = self._parse_csv(file_content or path.read_bytes())
            elif ext in {".xlsx", ".xls"}:
                cards_data = self._parse_excel(file_content or path.read_bytes())
            else:
                raise ValueError(f"Unsupported format: {ext}")

            # Save to database
            imported_count = self._save_cards(cards_data, batch_id, path.name)

            # Log activity
            self._log_activity(
                action="import",
                target=path.name,
                details=f"Imported {imported_count} cards in batch {batch_id}",
                status="success"
            )

            return {
                "success": True,
                "batch_id": batch_id,
                "imported_count": imported_count,
                "source_file": path.name,
                "format": ext,
            }

        except Exception as e:
            self._log_activity(
                action="import",
                target=path.name,
                details=str(e),
                status="error"
            )
            raise

    def _parse_txt(self, content: bytes) -> List[Dict]:
        """Parse TXT file. Expected format: username,password per line."""
        cards = []
        text = content.decode("utf-8", errors="ignore")
        lines = text.strip().split("\n")

        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            # Try comma-separated first
            if "," in line:
                parts = line.split(",", 1)
                username = parts[0].strip()
                password = parts[1].strip() if len(parts) > 1 else None
            else:
                # Assume username only
                username = line
                password = None

            if username:
                cards.append({
                    "username": username,
                    "password": password,
                    "card_type": "imported",
                    "line_number": line_num,
                })

        return cards

    def _parse_csv(self, content: bytes) -> List[Dict]:
        """Parse CSV file with flexible column mapping."""
        cards = []
        text = content.decode("utf-8", errors="ignore")
        reader = csv.DictReader(io.StringIO(text))

        # Normalize column names
        field_mapping = {
            "username": ["username", "user", "name", "login"],
            "password": ["password", "pass", "pwd"],
            "card_type": ["type", "card_type", "category"],
            "notes": ["notes", "note", "comment", "description"],
        }

        for row_num, row in enumerate(reader, 1):
            # Map columns
            mapped = {}
            for target_field, source_fields in field_mapping.items():
                for src in source_fields:
                    if src in row and row[src]:
                        mapped[target_field] = row[src].strip()
                        break

            if "username" in mapped and mapped["username"]:
                cards.append({
                    "username": mapped.get("username"),
                    "password": mapped.get("password"),
                    "card_type": mapped.get("card_type", "imported"),
                    "notes": mapped.get("notes"),
                    "line_number": row_num,
                })

        return cards

    def _parse_excel(self, content: bytes) -> List[Dict]:
        """Parse Excel file (XLSX/XLS) with flexible column mapping."""
        cards = []
        df = pd.read_excel(io.BytesIO(content))

        # Normalize column names to lowercase
        df.columns = [str(c).lower().strip() for c in df.columns]

        # Map columns
        field_mapping = {
            "username": ["username", "user", "name", "login"],
            "password": ["password", "pass", "pwd"],
            "card_type": ["type", "card_type", "category"],
            "notes": ["notes", "note", "comment", "description"],
        }

        for idx, row in df.iterrows():
            mapped = {}
            for target_field, source_fields in field_mapping.items():
                for src in source_fields:
                    if src in df.columns and pd.notna(row[src]):
                        mapped[target_field] = str(row[src]).strip()
                        break

            if "username" in mapped and mapped["username"]:
                cards.append({
                    "username": mapped.get("username"),
                    "password": mapped.get("password"),
                    "card_type": mapped.get("card_type", "imported"),
                    "notes": mapped.get("notes"),
                    "line_number": idx + 1,
                })

        return cards

    def _save_cards(self, cards_data: List[Dict], batch_id: str, source_file: str) -> int:
        """Save parsed cards to database."""
        cards_to_add = []

        for data in cards_data:
            card = Card(
                username=data["username"],
                password=data.get("password"),
                card_type=data.get("card_type", "imported"),
                notes=data.get("notes"),
                source_file=source_file,
                batch_id=batch_id,
            )
            cards_to_add.append(card)

        if cards_to_add:
            self.db.add_all(cards_to_add)
            self.db.commit()

        return len(cards_to_add)

    def _log_activity(self, action: str, target: str, details: str, status: str):
        """Log import activity."""
        log = ActivityLog(
            action=action,
            target=target,
            details=details,
            status=status,
        )
        self.db.add(log)
        self.db.commit()
