"""
Multi-format export service.
Exports cards and analysis results to CSV, XLSX, JSON, and PDF.
"""
import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional

import pandas as pd
from sqlalchemy.orm import Session

from backend.models.card import Card
from backend.config import config


class ExportService:
    """Handles exporting data to various formats."""

    def __init__(self, db: Session):
        self.db = db
        self.exports_dir = config.exports_dir
        self.exports_dir.mkdir(parents=True, exist_ok=True)

    def export_cards_csv(self, batch_id: Optional[str] = None) -> str:
        """Export cards to CSV format."""
        query = self.db.query(Card)
        if batch_id:
            query = query.filter(Card.batch_id == batch_id)

        cards = query.all()
        data = [card.to_dict() for card in cards]

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"cards_export_{timestamp}.csv"
        filepath = self.exports_dir / filename

        df = pd.DataFrame(data)
        df.to_csv(filepath, index=False, encoding="utf-8-sig")

        return str(filepath)

    def export_cards_excel(self, batch_id: Optional[str] = None) -> str:
        """Export cards to Excel format."""
        query = self.db.query(Card)
        if batch_id:
            query = query.filter(Card.batch_id == batch_id)

        cards = query.all()
        data = [card.to_dict() for card in cards]

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"cards_export_{timestamp}.xlsx"
        filepath = self.exports_dir / filename

        df = pd.DataFrame(data)
        df.to_excel(filepath, index=False, engine="openpyxl")

        return str(filepath)

    def export_cards_json(self, batch_id: Optional[str] = None) -> str:
        """Export cards to JSON format."""
        query = self.db.query(Card)
        if batch_id:
            query = query.filter(Card.batch_id == batch_id)

        cards = query.all()
        data = [card.to_dict() for card in cards]

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"cards_export_{timestamp}.json"
        filepath = self.exports_dir / filename

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        return str(filepath)

    def export_analysis_report(self, analysis_data: Dict) -> str:
        """Export analysis results to JSON."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"analysis_report_{timestamp}.json"
        filepath = self.exports_dir / filename

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(analysis_data, f, ensure_ascii=False, indent=2)

        return str(filepath)

    def export_test_sessions_csv(self) -> str:
        """Export test session logs to CSV."""
        from backend.models.test_session import TestSession

        sessions = self.db.query(TestSession).all()
        data = [session.to_dict() for session in sessions]

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"test_sessions_{timestamp}.csv"
        filepath = self.exports_dir / filename

        df = pd.DataFrame(data)
        df.to_csv(filepath, index=False, encoding="utf-8-sig")

        return str(filepath)

    def get_export_history(self) -> List[Dict]:
        """List all exported files."""
        files = []
        for filepath in self.exports_dir.glob("*"):
            if filepath.is_file():
                files.append({
                    "filename": filepath.name,
                    "path": str(filepath),
                    "size_bytes": filepath.stat().st_size,
                    "created_at": datetime.fromtimestamp(filepath.stat().st_ctime).isoformat(),
                })
        return sorted(files, key=lambda x: x["created_at"], reverse=True)
