"""
Seed-based synthetic data generator.
Generates test credentials with reproducible results using random seeds.
"""
import random
import string
from typing import List, Dict, Optional


class SyntheticGenerator:
    """Generates synthetic test credentials."""

    def __init__(self, seed: Optional[int] = None):
        """
        Initialize generator with optional seed for reproducibility.
        
        Args:
            seed: Random seed for reproducible generation
        """
        self.seed = seed
        if seed is not None:
            random.seed(seed)

    def generate_batch(
        self,
        count: int = 100,
        username_length: int = 8,
        password_length: int = 6,
        prefix: str = "",
        suffix: str = "",
        username_chars: str = "alphanumeric",
        password_chars: str = "alphanumeric",
        include_password: bool = True,
    ) -> List[Dict]:
        """
        Generate a batch of synthetic credentials.
        
        Args:
            count: Number of credentials to generate
            username_length: Length of username (excluding prefix/suffix)
            password_length: Length of password
            prefix: Fixed prefix for usernames
            suffix: Fixed suffix for usernames
            username_chars: Character set for username ('alpha', 'numeric', 'alphanumeric')
            password_chars: Character set for password ('alpha', 'numeric', 'alphanumeric', 'all')
            include_password: Whether to generate passwords
            
        Returns:
            List of credential dicts
        """
        credentials = []

        # Determine character sets
        username_charset = self._get_charset(username_chars)
        password_charset = self._get_charset(password_chars)

        for i in range(count):
            # Generate username
            username_body = ''.join(random.choices(username_charset, k=username_length))
            username = f"{prefix}{username_body}{suffix}"

            # Generate password
            password = None
            if include_password:
                password = ''.join(random.choices(password_charset, k=password_length))

            credentials.append({
                "username": username,
                "password": password,
                "index": i + 1,
            })

        return credentials

    def generate_from_pattern(
        self,
        pattern: str,
        count: int = 100,
        include_password: bool = True,
        password_length: int = 6,
    ) -> List[Dict]:
        """
        Generate credentials based on a pattern template.
        
        Pattern syntax:
        - {A} = random letter
        - {N} = random digit
        - {X} = random alphanumeric
        - Fixed text is preserved
        
        Example: "USR{NNN}" generates "USR123", "USR456", etc.
        
        Args:
            pattern: Pattern template
            count: Number of credentials to generate
            include_password: Whether to generate passwords
            password_length: Length of password
            
        Returns:
            List of credential dicts
        """
        credentials = []

        for i in range(count):
            # Expand pattern
            username = self._expand_pattern(pattern)

            # Generate password
            password = None
            if include_password:
                password = ''.join(
                    random.choices(string.ascii_letters + string.digits, k=password_length)
                )

            credentials.append({
                "username": username,
                "password": password,
                "pattern": pattern,
                "index": i + 1,
            })

        return credentials

    def _expand_pattern(self, pattern: str) -> str:
        """Expand a pattern template into a concrete string."""
        result = []
        i = 0

        while i < len(pattern):
            if pattern[i:i+3] == "{A}":
                result.append(random.choice(string.ascii_letters))
                i += 3
            elif pattern[i:i+3] == "{N}":
                result.append(random.choice(string.digits))
                i += 3
            elif pattern[i:i+3] == "{X}":
                result.append(random.choice(string.ascii_letters + string.digits))
                i += 3
            else:
                result.append(pattern[i])
                i += 1

        return ''.join(result)

    @staticmethod
    def _get_charset(charset_name: str) -> str:
        """Get character set by name."""
        charsets = {
            "alpha": string.ascii_letters,
            "numeric": string.digits,
            "alphanumeric": string.ascii_letters + string.digits,
            "all": string.ascii_letters + string.digits + string.punctuation,
        }
        return charsets.get(charset_name, string.ascii_letters + string.digits)

    def compare_with_sample(
        self,
        generated: List[Dict],
        sample_usernames: List[str],
    ) -> Dict:
        """
        Compare generated credentials with a sample set.
        
        Args:
            generated: List of generated credentials
            sample_usernames: List of sample usernames to compare against
            
        Returns:
            Comparison statistics
        """
        if not sample_usernames:
            return {"error": "no_sample_data"}

        # Analyze sample
        sample_lengths = [len(u) for u in sample_usernames]
        sample_avg_length = sum(sample_lengths) / len(sample_lengths)

        # Analyze generated
        gen_lengths = [len(c["username"]) for c in generated]
        gen_avg_length = sum(gen_lengths) / len(gen_lengths)

        return {
            "sample_size": len(sample_usernames),
            "generated_size": len(generated),
            "sample_avg_length": round(sample_avg_length, 2),
            "generated_avg_length": round(gen_avg_length, 2),
            "length_difference": round(abs(sample_avg_length - gen_avg_length), 2),
            "match_quality": "good" if abs(sample_avg_length - gen_avg_length) < 1 else "fair",
        }
