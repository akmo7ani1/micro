"""Generators package initialization."""
from backend.generators.synthetic_generator import SyntheticGenerator

__all__ = ["SyntheticGenerator"]