"""
Excel report generator using OpenPyXL.
Generates professional Excel reports with multiple sheets.
"""
from datetime import datetime
from pathlib import Path
from typing import Dict, List

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from backend.config import config


class ExcelReporter:
    """Generates Excel reports from analysis data."""

    def __init__(self):
        self.exports_dir = config.exports_dir
        self.exports_dir.mkdir(parents=True, exist_ok=True)

    def generate_analysis_report(self, analysis_data: Dict) -> str:
        """
        Generate an Excel report from analysis data.
        
        Args:
            analysis_data: Analysis results from PatternAnalyzer
            
        Returns:
            Path to generated Excel file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"analysis_report_{timestamp}.xlsx"
        filepath = self.exports_dir / filename

        wb = Workbook()

        # Summary sheet
        ws_summary = wb.active
        ws_summary.title = "Summary"
        self._create_summary_sheet(ws_summary, analysis_data)

        # Username analysis sheet
        if "username_analysis" in analysis_data:
            ws_username = wb.create_sheet("Username Analysis")
            self._create_username_sheet(ws_username, analysis_data["username_analysis"])

        # Password analysis sheet
        if "password_analysis" in analysis_data:
            ws_password = wb.create_sheet("Password Analysis")
            self._create_password_sheet(ws_password, analysis_data["password_analysis"])

        # Patterns sheet
        if "pattern_analysis" in analysis_data:
            ws_patterns = wb.create_sheet("Patterns")
            self._create_patterns_sheet(ws_patterns, analysis_data["pattern_analysis"])

        # Relationships sheet
        if "relationship_analysis" in analysis_data:
            ws_relations = wb.create_sheet("Relationships")
            self._create_relationships_sheet(ws_relations, analysis_data["relationship_analysis"])

        wb.save(filepath)

        return str(filepath)

    def _create_summary_sheet(self, ws, data: Dict):
        """Create summary sheet."""
        # Header style
        header_fill = PatternFill(start_color="38BDF8", end_color="38BDF8", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF", size=12)

        ws["A1"] = "MikroTik Card Analysis Report"
        ws["A1"].font = Font(bold=True, size=16)
        ws["A2"] = f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

        row = 4
        ws.cell(row, 1, "Metric").fill = header_fill
        ws.cell(row, 1).font = header_font
        ws.cell(row, 2, "Value").fill = header_fill
        ws.cell(row, 2).font = header_font

        row += 1
        ws.cell(row, 1, "Total Cards")
        ws.cell(row, 2, data.get("total_cards", 0))

        # Auto-size columns
        ws.column_dimensions['A'].width = 20
        ws.column_dimensions['B'].width = 15

    def _create_username_sheet(self, ws, data: Dict):
        """Create username analysis sheet."""
        header_fill = PatternFill(start_color="38BDF8", end_color="38BDF8", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")

        # Length statistics
        ws["A1"] = "Username Length Statistics"
        ws["A1"].font = Font(bold=True, size=14)

        if "length_stats" in data:
            stats = data["length_stats"]
            ws["A3"] = "Min Length"
            ws["B3"] = stats.get("min", 0)
            ws["A4"] = "Max Length"
            ws["B4"] = stats.get("max", 0)
            ws["A5"] = "Average Length"
            ws["B5"] = f"{stats.get('avg', 0):.2f}"

        # Common prefixes
        row = 7
        ws.cell(row, 1, "Common Prefixes").font = Font(bold=True, size=12)
        row += 1
        ws.cell(row, 1, "Prefix").fill = header_fill
        ws.cell(row, 1).font = header_font
        ws.cell(row, 2, "Count").fill = header_fill
        ws.cell(row, 2).font = header_font

        row += 1
        if "common_prefixes" in data:
            for prefix, count in list(data["common_prefixes"].items())[:20]:
                ws.cell(row, 1, prefix)
                ws.cell(row, 2, count)
                row += 1

        # Auto-size columns
        ws.column_dimensions['A'].width = 20
        ws.column_dimensions['B'].width = 15

    def _create_password_sheet(self, ws, data: Dict):
        """Create password analysis sheet."""
        if not data.get("has_passwords"):
            ws["A1"] = "No passwords found in dataset"
            return

        header_fill = PatternFill(start_color="38BDF8", end_color="38BDF8", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")

        ws["A1"] = "Password Analysis"
        ws["A1"].font = Font(bold=True, size=14)

        if "length_stats" in data:
            stats = data["length_stats"]
            ws["A3"] = "Min Length"
            ws["B3"] = stats.get("min", 0)
            ws["A4"] = "Max Length"
            ws["B4"] = stats.get("max", 0)
            ws["A5"] = "Average Length"
            ws["B5"] = f"{stats.get('avg', 0):.2f}"

        ws.column_dimensions['A'].width = 20
        ws.column_dimensions['B'].width = 15

    def _create_patterns_sheet(self, ws, data: Dict):
        """Create patterns sheet."""
        header_fill = PatternFill(start_color="38BDF8", end_color="38BDF8", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")

        ws["A1"] = "Detected Patterns"
        ws["A1"].font = Font(bold=True, size=14)

        row = 3
        ws.cell(row, 1, "Pattern").fill = header_fill
        ws.cell(row, 1).font = header_font
        ws.cell(row, 2, "Count").fill = header_fill
        ws.cell(row, 2).font = header_font
        ws.cell(row, 3, "Percentage").fill = header_fill
        ws.cell(row, 3).font = header_font
        ws.cell(row, 4, "Confidence").fill = header_fill
        ws.cell(row, 4).font = header_font

        row += 1
        patterns = data.get("detected_patterns", {})
        for pattern, info in patterns.items():
            ws.cell(row, 1, pattern)
            ws.cell(row, 2, info.get("count", 0))
            ws.cell(row, 3, f"{info.get('percentage', 0):.1f}%")
            ws.cell(row, 4, info.get("confidence", "unknown"))
            row += 1

        ws.column_dimensions['A'].width = 25
        ws.column_dimensions['B'].width = 12
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 15

    def _create_relationships_sheet(self, ws, data: Dict):
        """Create relationships sheet."""
        header_fill = PatternFill(start_color="38BDF8", end_color="38BDF8", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")

        ws["A1"] = "Username-Password Relationships"
        ws["A1"].font = Font(bold=True, size=14)

        row = 3
        ws.cell(row, 1, "Relationship").fill = header_fill
        ws.cell(row, 1).font = header_font
        ws.cell(row, 2, "Count").fill = header_fill
        ws.cell(row, 2).font = header_font

        row += 1
        for relationship, count in data.items():
            ws.cell(row, 1, relationship.replace("_", " ").title())
            ws.cell(row, 2, count)
            row += 1

        ws.column_dimensions['A'].width = 35
        ws.column_dimensions['B'].width = 15

    def generate_cards_report(self, cards_data: List[Dict]) -> str:
        """
        Generate an Excel report listing all cards.
        
        Args:
            cards_data: List of card dicts
            
        Returns:
            Path to generated Excel file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"cards_report_{timestamp}.xlsx"
        filepath = self.exports_dir / filename

        wb = Workbook()
        ws = wb.active
        ws.title = "Cards"

        # Header
        header_fill = PatternFill(start_color="38BDF8", end_color="38BDF8", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")

        headers = ["ID", "Username", "Password", "Type", "Batch", "Created"]
        for col, header in enumerate(headers, 1):
            cell = ws.cell(1, col, header)
            cell.fill = header_fill
            cell.font = header_font

        # Data rows
        for row, card in enumerate(cards_data, 2):
            ws.cell(row, 1, card.get("id"))
            ws.cell(row, 2, card.get("username"))
            ws.cell(row, 3, card.get("password") or "")
            ws.cell(row, 4, card.get("card_type"))
            ws.cell(row, 5, card.get("batch_id"))
            ws.cell(row, 6, card.get("created_at"))

        # Auto-size columns
        for col in range(1, len(headers) + 1):
            ws.column_dimensions[get_column_letter(col)].width = 18

        wb.save(filepath)

        return str(filepath)
