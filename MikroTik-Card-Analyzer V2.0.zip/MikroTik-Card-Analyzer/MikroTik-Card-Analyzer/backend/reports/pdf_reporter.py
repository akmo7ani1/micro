"""
PDF report generator using ReportLab.
Generates professional PDF reports for analysis results.
"""
from datetime import datetime
from pathlib import Path
from typing import Dict, List

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    PageBreak,
)
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT

from backend.config import config


class PDFReporter:
    """Generates PDF reports from analysis data."""

    def __init__(self):
        self.exports_dir = config.exports_dir
        self.exports_dir.mkdir(parents=True, exist_ok=True)

    def generate_analysis_report(self, analysis_data: Dict) -> str:
        """
        Generate a PDF report from analysis data.
        
        Args:
            analysis_data: Analysis results from PatternAnalyzer
            
        Returns:
            Path to generated PDF file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"analysis_report_{timestamp}.pdf"
        filepath = self.exports_dir / filename

        # Create PDF document
        doc = SimpleDocTemplate(
            str(filepath),
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=18,
        )

        # Container for the 'Flowable' objects
        elements = []

        # Styles
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1e293b'),
            spaceAfter=30,
            alignment=TA_CENTER,
        )
        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=16,
            textColor=colors.HexColor('#334155'),
            spaceAfter=12,
            spaceBefore=12,
        )

        # Title
        elements.append(Paragraph("MikroTik Card Analysis Report", title_style))
        elements.append(Paragraph(
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            styles['Normal']
        ))
        elements.append(Spacer(1, 0.3 * inch))

        # Summary
        if "total_cards" in analysis_data:
            elements.append(Paragraph("Summary", heading_style))
            summary_data = [
                ["Metric", "Value"],
                ["Total Cards", str(analysis_data["total_cards"])],
            ]
            summary_table = Table(summary_data, colWidths=[3 * inch, 2 * inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#38bdf8')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f1f5f9')),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
            ]))
            elements.append(summary_table)
            elements.append(Spacer(1, 0.3 * inch))

        # Username Analysis
        if "username_analysis" in analysis_data:
            elements.append(Paragraph("Username Analysis", heading_style))
            ua = analysis_data["username_analysis"]
            
            if "length_stats" in ua:
                stats = ua["length_stats"]
                elements.append(Paragraph(f"<b>Length Statistics:</b>", styles['Normal']))
                elements.append(Paragraph(f"Min: {stats.get('min', 0)}", styles['Normal']))
                elements.append(Paragraph(f"Max: {stats.get('max', 0)}", styles['Normal']))
                elements.append(Paragraph(f"Average: {stats.get('avg', 0):.2f}", styles['Normal']))
                elements.append(Spacer(1, 0.2 * inch))

            if "common_prefixes" in ua:
                elements.append(Paragraph(f"<b>Top Prefixes:</b>", styles['Normal']))
                prefix_data = [["Prefix", "Count"]]
                for prefix, count in list(ua["common_prefixes"].items())[:10]:
                    prefix_data.append([prefix, str(count)])
                
                prefix_table = Table(prefix_data, colWidths=[2.5 * inch, 1.5 * inch])
                prefix_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#38bdf8')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
                ]))
                elements.append(prefix_table)
                elements.append(Spacer(1, 0.2 * inch))

        # Password Analysis
        if "password_analysis" in analysis_data:
            pa = analysis_data["password_analysis"]
            if pa.get("has_passwords"):
                elements.append(Paragraph("Password Analysis", heading_style))
                
                if "length_stats" in pa:
                    stats = pa["length_stats"]
                    elements.append(Paragraph(f"<b>Length Statistics:</b>", styles['Normal']))
                    elements.append(Paragraph(f"Min: {stats.get('min', 0)}", styles['Normal']))
                    elements.append(Paragraph(f"Max: {stats.get('max', 0)}", styles['Normal']))
                    elements.append(Paragraph(f"Average: {stats.get('avg', 0):.2f}", styles['Normal']))
                    elements.append(Spacer(1, 0.2 * inch))

        # Pattern Analysis
        if "pattern_analysis" in analysis_data:
            elements.append(Paragraph("Detected Patterns", heading_style))
            patterns = analysis_data["pattern_analysis"].get("detected_patterns", {})
            
            if patterns:
                pattern_data = [["Pattern", "Count", "Percentage", "Confidence"]]
                for pattern, info in patterns.items():
                    pattern_data.append([
                        pattern,
                        str(info.get("count", 0)),
                        f"{info.get('percentage', 0):.1f}%",
                        info.get("confidence", "unknown"),
                    ])
                
                pattern_table = Table(pattern_data, colWidths=[2 * inch, 1 * inch, 1 * inch, 1 * inch])
                pattern_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#38bdf8')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
                ]))
                elements.append(pattern_table)

        # Build PDF
        doc.build(elements)

        return str(filepath)

    def generate_cards_report(self, cards_data: List[Dict]) -> str:
        """
        Generate a PDF report listing all cards.
        
        Args:
            cards_data: List of card dicts
            
        Returns:
            Path to generated PDF file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"cards_report_{timestamp}.pdf"
        filepath = self.exports_dir / filename

        doc = SimpleDocTemplate(str(filepath), pagesize=A4)
        elements = []

        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=20,
            alignment=TA_CENTER,
        )

        elements.append(Paragraph("Cards Export Report", title_style))
        elements.append(Paragraph(
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            styles['Normal']
        ))
        elements.append(Spacer(1, 0.3 * inch))

        # Cards table
        if cards_data:
            table_data = [["ID", "Username", "Password", "Type"]]
            for card in cards_data[:100]:  # Limit to 100 for PDF
                table_data.append([
                    str(card.get("id", "")),
                    card.get("username", ""),
                    card.get("password", "") or "",
                    card.get("card_type", ""),
                ])

            table = Table(table_data, colWidths=[0.5 * inch, 2 * inch, 2 * inch, 1.5 * inch])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#38bdf8')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
            ]))
            elements.append(table)

        doc.build(elements)

        return str(filepath)
