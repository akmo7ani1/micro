"""
Rate limiter for authentication testing.
Prevents excessive requests and implements circuit breaker pattern.
"""
import time
from typing import Dict, List
from collections import deque

from backend.config import config


class RateLimiter:
    """
    Rate limiter with sliding window and circuit breaker.
    
    Features:
    - Sliding window rate limiting
    - Circuit breaker for repeated failures
    - Configurable delays between requests
    """

    def __init__(self):
        self.max_retries = config.get("authentication_lab.max_retries", 3)
        self.circuit_breaker_threshold = config.get(
            "authentication_lab.circuit_breaker_threshold", 10
        )
        self.default_delay_ms = config.get("authentication_lab.default_delay_ms", 500)
        
        # Sliding window for recent attempts
        self.attempts_window = deque(maxlen=100)
        self.consecutive_failures = 0
        self.circuit_open_until = 0

    def can_proceed(self) -> bool:
        """
        Check if a request can proceed based on rate limits.
        
        Returns:
            True if request can proceed, False if rate limited
        """
        current_time = time.time()

        # Check if circuit breaker is open
        if current_time < self.circuit_open_until:
            return False

        # Check recent attempts (last 60 seconds)
        recent_attempts = [
            t for t in self.attempts_window
            if current_time - t < 60
        ]

        # Allow max 30 requests per minute
        if len(recent_attempts) >= 30:
            return False

        # Check consecutive failures
        if self.consecutive_failures >= self.circuit_breaker_threshold:
            # Open circuit for 5 minutes
            self.circuit_open_until = current_time + 300
            return False

        return True

    def record_attempt(self, success: bool = True):
        """
        Record an authentication attempt.
        
        Args:
            success: Whether the attempt was successful
        """
        current_time = time.time()
        self.attempts_window.append(current_time)

        if success:
            self.consecutive_failures = 0
        else:
            self.consecutive_failures += 1

    def get_delay_ms(self) -> int:
        """
        Get recommended delay before next request.
        
        Returns:
            Delay in milliseconds
        """
        # Increase delay based on consecutive failures
        base_delay = self.default_delay_ms
        failure_multiplier = min(self.consecutive_failures, 5)
        
        return base_delay * (1 + failure_multiplier * 0.5)

    def reset(self):
        """Reset all rate limiting state."""
        self.attempts_window.clear()
        self.consecutive_failures = 0
        self.circuit_open_until = 0

    def get_status(self) -> Dict:
        """
        Get current rate limiter status.
        
        Returns:
            Dict with status information
        """
        current_time = time.time()
        recent_attempts = [
            t for t in self.attempts_window
            if current_time - t < 60
        ]

        return {
            "recent_attempts_60s": len(recent_attempts),
            "consecutive_failures": self.consecutive_failures,
            "circuit_breaker_open": current_time < self.circuit_open_until,
            "circuit_opens_until": self.circuit_open_until if current_time < self.circuit_open_until else None,
            "recommended_delay_ms": self.get_delay_ms(),
        }
