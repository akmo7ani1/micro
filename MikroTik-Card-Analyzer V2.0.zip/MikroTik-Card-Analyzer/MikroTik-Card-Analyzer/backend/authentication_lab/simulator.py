"""
Local authentication simulator.
Simulates MikroTik hotspot authentication for testing without external dependencies.
"""
import hashlib
import time
from typing import Dict, Optional, List
from dataclasses import dataclass, field


@dataclass
class SimulatedAccount:
    """Represents a simulated test account."""
    username: str
    password: Optional[str]
    auth_mode: str  # "username_only" or "username_password"
    is_valid: bool
    session_id: Optional[str] = None
    login_time: Optional[float] = None
    last_activity: Optional[float] = None


@dataclass
class SimulatedSession:
    """Represents an active authentication session."""
    session_id: str
    username: str
    auth_mode: str
    start_time: float
    last_activity: float
    is_active: bool = True


class AuthSimulator:
    """
    Local authentication simulator for testing.
    
    Features:
    - Simulates username-only and username+password authentication
    - Session management with timeouts
    - Success/failure simulation
    - No external network dependencies
    """

    def __init__(self):
        self.accounts: Dict[str, SimulatedAccount] = {}
        self.sessions: Dict[str, SimulatedSession] = {}
        self.session_timeout_seconds = 3600  # 1 hour default

    def create_account(
        self,
        username: str,
        password: Optional[str] = None,
        auth_mode: str = "username_password",
        is_valid: bool = True,
    ) -> SimulatedAccount:
        """
        Create a simulated test account.
        
        Args:
            username: Account username
            password: Account password (optional for username_only mode)
            auth_mode: "username_only" or "username_password"
            is_valid: Whether this account should authenticate successfully
            
        Returns:
            Created SimulatedAccount
        """
        account = SimulatedAccount(
            username=username,
            password=password,
            auth_mode=auth_mode,
            is_valid=is_valid,
        )
        self.accounts[username] = account
        return account

    def authenticate(
        self,
        username: str,
        password: Optional[str] = None,
        auth_mode: str = "username_password",
    ) -> Dict:
        """
        Attempt authentication against simulated accounts.
        
        Args:
            username: Username to authenticate
            password: Password to authenticate (optional)
            auth_mode: Expected authentication mode
            
        Returns:
            Dict with authentication result
        """
        start_time = time.time()

        # Check if account exists
        if username not in self.accounts:
            return {
                "success": False,
                "error": "account_not_found",
                "message": f"Account '{username}' not found",
                "response_time_ms": (time.time() - start_time) * 1000,
            }

        account = self.accounts[username]

        # Check if account is valid
        if not account.is_valid:
            return {
                "success": False,
                "error": "account_disabled",
                "message": "Account is disabled",
                "response_time_ms": (time.time() - start_time) * 1000,
            }

        # Validate authentication mode
        if account.auth_mode != auth_mode:
            return {
                "success": False,
                "error": "auth_mode_mismatch",
                "message": f"Expected {account.auth_mode}, got {auth_mode}",
                "response_time_ms": (time.time() - start_time) * 1000,
            }

        # Validate credentials
        if auth_mode == "username_password":
            if password is None or account.password != password:
                return {
                    "success": False,
                    "error": "invalid_credentials",
                    "message": "Invalid username or password",
                    "response_time_ms": (time.time() - start_time) * 1000,
                }

        # Authentication successful - create session
        session_id = self._generate_session_id(username)
        session = SimulatedSession(
            session_id=session_id,
            username=username,
            auth_mode=auth_mode,
            start_time=time.time(),
            last_activity=time.time(),
        )
        self.sessions[session_id] = session

        # Update account
        account.session_id = session_id
        account.login_time = time.time()
        account.last_activity = time.time()

        return {
            "success": True,
            "session_id": session_id,
            "username": username,
            "auth_mode": auth_mode,
            "response_time_ms": (time.time() - start_time) * 1000,
        }

    def validate_session(self, session_id: str) -> Dict:
        """
        Validate an active session.
        
        Args:
            session_id: Session ID to validate
            
        Returns:
            Dict with validation result
        """
        if session_id not in self.sessions:
            return {
                "valid": False,
                "error": "session_not_found",
            }

        session = self.sessions[session_id]

        # Check if session is active
        if not session.is_active:
            return {
                "valid": False,
                "error": "session_inactive",
            }

        # Check timeout
        elapsed = time.time() - session.last_activity
        if elapsed > self.session_timeout_seconds:
            session.is_active = False
            return {
                "valid": False,
                "error": "session_expired",
            }

        # Update last activity
        session.last_activity = time.time()

        return {
            "valid": True,
            "username": session.username,
            "auth_mode": session.auth_mode,
            "start_time": session.start_time,
            "elapsed_seconds": elapsed,
        }

    def logout(self, session_id: str) -> Dict:
        """
        Logout and invalidate a session.
        
        Args:
            session_id: Session ID to logout
            
        Returns:
            Dict with logout result
        """
        if session_id not in self.sessions:
            return {
                "success": False,
                "error": "session_not_found",
            }

        session = self.sessions[session_id]
        session.is_active = False

        # Update account
        if session.username in self.accounts:
            account = self.accounts[session.username]
            account.session_id = None

        return {
            "success": True,
            "message": "Logged out successfully",
        }

    def get_active_sessions(self) -> List[Dict]:
        """
        Get all active sessions.
        
        Returns:
            List of active session dicts
        """
        active = []
        for session_id, session in self.sessions.items():
            if session.is_active:
                # Check timeout
                elapsed = time.time() - session.last_activity
                if elapsed <= self.session_timeout_seconds:
                    active.append({
                        "session_id": session_id,
                        "username": session.username,
                        "auth_mode": session.auth_mode,
                        "start_time": session.start_time,
                        "elapsed_seconds": elapsed,
                    })

        return active

    def cleanup_expired_sessions(self):
        """Remove expired sessions."""
        current_time = time.time()
        expired = [
            sid for sid, session in self.sessions.items()
            if current_time - session.last_activity > self.session_timeout_seconds
        ]

        for session_id in expired:
            session = self.sessions[session_id]
            session.is_active = False
            
            # Update account
            if session.username in self.accounts:
                account = self.accounts[session.username]
                account.session_id = None

    @staticmethod
    def _generate_session_id(username: str) -> str:
        """Generate a unique session ID."""
        timestamp = str(time.time()).encode()
        username_bytes = username.encode()
        hash_input = timestamp + username_bytes
        return hashlib.sha256(hash_input).hexdigest()[:32]
