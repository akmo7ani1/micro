"""
Session manager for authentication testing.
Coordinates between real HTTP testing and local simulation.
"""
import time
from typing import Dict, Optional

import httpx
from bs4 import BeautifulSoup
from sqlalchemy.orm import Session as DBSession

from backend.models.test_session import TestSession
from backend.models.activity_log import ActivityLog
from backend.authentication_lab.simulator import AuthSimulator
from backend.config import config


class SessionManager:
    """
    Manages authentication test sessions.
    
    Supports:
    - Real HTTP authentication testing
    - Local simulation mode
    - Session logging and tracking
    """

    def __init__(self, db: DBSession):
        self.db = db
        self.simulator = AuthSimulator()
        self.timeout_seconds = config.get("authentication_lab.timeout_seconds", 10)

    async def test_authentication(
        self,
        target_url: str,
        username: str,
        password: Optional[str] = None,
        auth_mode: str = "username_password",
        timeout: int = None,
        use_simulator: bool = False,
    ) -> Dict:
        """
        Test authentication against a target URL or simulator.
        
        Args:
            target_url: URL to test against (ignored if use_simulator=True)
            username: Username to test
            password: Password to test (optional)
            auth_mode: "username_only" or "username_password"
            timeout: Request timeout in seconds
            use_simulator: Use local simulator instead of real HTTP
            
        Returns:
            Dict with test result
        """
        if timeout is None:
            timeout = self.timeout_seconds

        start_time = time.time()

        try:
            if use_simulator:
                result = self._test_with_simulator(username, password, auth_mode)
            else:
                result = await self._test_with_http(
                    target_url, username, password, auth_mode, timeout
                )

            # Log session
            session_log = TestSession(
                target_url=target_url if not use_simulator else "simulator://local",
                username=username,
                auth_mode=auth_mode,
                success=result["success"],
                http_status=result.get("http_status"),
                response_time_ms=result.get("response_time_ms"),
                error_message=result.get("error"),
                session_id=result.get("session_id"),
            )
            self.db.add(session_log)
            self.db.commit()

            # Log activity
            log = ActivityLog(
                action="test_auth",
                target=username,
                details=f"Auth test {'succeeded' if result['success'] else 'failed'}",
                status="success" if result["success"] else "error",
            )
            self.db.add(log)
            self.db.commit()

            return result

        except Exception as e:
            # Log error
            session_log = TestSession(
                target_url=target_url,
                username=username,
                auth_mode=auth_mode,
                success=False,
                response_time_ms=(time.time() - start_time) * 1000,
                error_message=str(e),
            )
            self.db.add(session_log)
            self.db.commit()

            raise

    async def _test_with_http(
        self,
        target_url: str,
        username: str,
        password: Optional[str],
        auth_mode: str,
        timeout: int,
    ) -> Dict:
        """
        Test authentication via real HTTP request.
        
        Args:
            target_url: URL to test
            username: Username
            password: Password
            auth_mode: Authentication mode
            timeout: Request timeout
            
        Returns:
            Dict with test result
        """
        start_time = time.time()

        try:
            async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
                # First, fetch the login page to extract form structure
                response = await client.get(target_url)
                response.raise_for_status()

                soup = BeautifulSoup(response.text, "html.parser")
                form = soup.find("form")

                if not form:
                    return {
                        "success": False,
                        "error": "no_form_found",
                        "message": "No login form found on page",
                        "http_status": response.status_code,
                        "response_time_ms": (time.time() - start_time) * 1000,
                    }

                # Extract form action
                action = form.get("action", "")
                if action and not action.startswith("http"):
                    # Relative URL
                    from urllib.parse import urljoin
                    action = urljoin(target_url, action)
                else:
                    action = target_url

                # Build payload
                payload = {}
                
                # Extract hidden fields
                for hidden in form.find_all("input", {"type": "hidden"}):
                    name = hidden.get("name")
                    value = hidden.get("value", "")
                    if name:
                        payload[name] = value

                # Add credentials
                if auth_mode == "username_only":
                    # Find username field
                    username_field = self._find_username_field(form)
                    if username_field:
                        payload[username_field] = username
                else:
                    # Find username and password fields
                    username_field = self._find_username_field(form)
                    password_field = self._find_password_field(form)
                    
                    if username_field:
                        payload[username_field] = username
                    if password_field and password:
                        payload[password_field] = password

                # Submit form
                submit_response = await client.post(action, data=payload)

                # Determine success based on response
                success = self._determine_success(submit_response, soup)

                return {
                    "success": success,
                    "http_status": submit_response.status_code,
                    "response_time_ms": (time.time() - start_time) * 1000,
                    "final_url": str(submit_response.url),
                }

        except httpx.TimeoutException:
            return {
                "success": False,
                "error": "timeout",
                "message": "Request timeout",
                "response_time_ms": (time.time() - start_time) * 1000,
            }
        except httpx.HTTPStatusError as e:
            return {
                "success": False,
                "error": "http_error",
                "message": f"HTTP {e.response.status_code}",
                "http_status": e.response.status_code,
                "response_time_ms": (time.time() - start_time) * 1000,
            }

    def _test_with_simulator(
        self,
        username: str,
        password: Optional[str],
        auth_mode: str,
    ) -> Dict:
        """
        Test authentication using local simulator.
        
        Args:
            username: Username
            password: Password
            auth_mode: Authentication mode
            
        Returns:
            Dict with test result
        """
        # Ensure account exists in simulator
        if username not in self.simulator.accounts:
            # Create a default test account
            self.simulator.create_account(
                username=username,
                password=password,
                auth_mode=auth_mode,
                is_valid=True,
            )

        return self.simulator.authenticate(username, password, auth_mode)

    @staticmethod
    def _find_username_field(form) -> Optional[str]:
        """Find the username input field name."""
        # Common username field names
        common_names = ["username", "user", "name", "login", "uname"]
        
        for inp in form.find_all("input"):
            input_type = inp.get("type", "text").lower()
            input_name = inp.get("name", "").lower()
            
            if input_type in ["text", "email"]:
                if any(name in input_name for name in common_names):
                    return inp.get("name")
        
        # Fallback: first text input
        for inp in form.find_all("input"):
            if inp.get("type", "text").lower() == "text":
                return inp.get("name")
        
        return None

    @staticmethod
    def _find_password_field(form) -> Optional[str]:
        """Find the password input field name."""
        for inp in form.find_all("input"):
            if inp.get("type", "").lower() == "password":
                return inp.get("name")
        return None

    @staticmethod
    def _determine_success(response: httpx.Response, original_soup: BeautifulSoup) -> bool:
        """
        Determine if authentication was successful based on response.
        
        Args:
            response: HTTP response
            original_soup: Original login page soup
            
        Returns:
            True if authentication appears successful
        """
        # Check for common success indicators
        success_indicators = [
            "status=1",
            "logged-in",
            "welcome",
            "redirect",
        ]

        response_text = response.text.lower()
        
        # Check URL changes (redirect after login)
        if response.url != response.request.url:
            return True

        # Check for success indicators in response
        for indicator in success_indicators:
            if indicator in response_text:
                return True

        # Check for error indicators
        error_indicators = [
            "invalid",
            "error",
            "failed",
            "incorrect",
        ]

        for indicator in error_indicators:
            if indicator in response_text:
                return False

        # Default: assume success if no errors found
        return True
