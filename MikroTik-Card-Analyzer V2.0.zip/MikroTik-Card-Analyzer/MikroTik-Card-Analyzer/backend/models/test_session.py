"""
TestSession: log of a single authentication attempt in the lab.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, Text
from sqlalchemy.sql import func

from backend.database.connection import Base


class TestSession(Base):
    __tablename__ = "test_sessions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    target_url = Column(String(1024), nullable=True)
    account_id = Column(Integer, nullable=True, index=True)
    username = Column(String(255), nullable=False)
    auth_mode = Column(String(16), nullable=False)
    success = Column(Boolean, nullable=False, default=False)
    http_status = Column(Integer, nullable=True)
    response_time_ms = Column(Float, nullable=True)
    error_message = Column(Text, nullable=True)
    session_id = Column(String(128), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "target_url": self.target_url,
            "account_id": self.account_id,
            "username": self.username,
            "auth_mode": self.auth_mode,
            "success": self.success,
            "http_status": self.http_status,
            "response_time_ms": self.response_time_ms,
            "error_message": self.error_message,
            "session_id": self.session_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
