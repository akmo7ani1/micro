"""
TestAccount: a credential record used exclusively in the authentication lab.
These records are isolated from imported production cards.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime
from sqlalchemy.sql import func

from backend.database.connection import Base


class TestAccount(Base):
    __tablename__ = "test_accounts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(255), nullable=False, index=True)
    password = Column(String(255), nullable=True)
    auth_mode = Column(String(16), nullable=False, default="username_password")
    is_valid = Column(Boolean, nullable=False, default=True)
    notes = Column(String(512), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "username": self.username,
            "password": self.password,
            "auth_mode": self.auth_mode,
            "is_valid": self.is_valid,
            "notes": self.notes,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
