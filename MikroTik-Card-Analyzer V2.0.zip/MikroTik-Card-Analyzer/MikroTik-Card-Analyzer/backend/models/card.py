"""
Card entity: represents an imported MikroTik hotspot credential record.
"""
from datetime import datetime

from sqlalchemy import Column, Integer, String, Text, DateTime, Index
from sqlalchemy.sql import func

from backend.database.connection import Base


class Card(Base):
    __tablename__ = "cards"

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(255), nullable=False, index=True)
    password = Column(String(255), nullable=True)
    card_type = Column(String(64), nullable=False, default="standard")
    notes = Column(Text, nullable=True)
    source_file = Column(String(512), nullable=True)
    batch_id = Column(String(64), nullable=True, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=datetime.utcnow,
    )

    __table_args__ = (
        Index("ix_cards_username_password", "username", "password"),
        Index("ix_cards_batch_created", "batch_id", "created_at"),
    )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "username": self.username,
            "password": self.password,
            "card_type": self.card_type,
            "notes": self.notes,
            "source_file": self.source_file,
            "batch_id": self.batch_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
