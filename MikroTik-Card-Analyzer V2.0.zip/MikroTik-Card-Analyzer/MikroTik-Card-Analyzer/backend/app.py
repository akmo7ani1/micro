"""
FastAPI application entry point.
Registers routers, middleware, startup hooks, and serves the frontend.
"""
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from backend.config import config
from backend.database.connection import init_db
from backend.routers import (
    cards,
    analysis,
    generator,
    inspector,
    auth_lab,
    reports,
    settings,
)


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("mikrotik_analyzer")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup/shutdown lifecycle."""
    logger.info("Initializing database...")
    init_db()
    logger.info("Database ready at %s", config.db_path)
    yield
    logger.info("Shutting down.")


app = FastAPI(
    title=config.get("app_name"),
    version=config.get("version"),
    lifespan=lifespan,
)

# CORS: permissive for local tooling; tighten in production deployments.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content={"error": "internal_error", "message": str(exc)},
    )


# API routers
app.include_router(cards.router, prefix="/api/cards", tags=["cards"])
app.include_router(analysis.router, prefix="/api/analysis", tags=["analysis"])
app.include_router(generator.router, prefix="/api/generator", tags=["generator"])
app.include_router(inspector.router, prefix="/api/inspector", tags=["inspector"])
app.include_router(auth_lab.router, prefix="/api/auth-lab", tags=["auth-lab"])
app.include_router(reports.router, prefix="/api/reports", tags=["reports"])
app.include_router(settings.router, prefix="/api/settings", tags=["settings"])


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "version": config.get("version"),
        "database": str(config.db_path),
    }


# Serve frontend static files last so API routes take precedence.
frontend_dir = config.root / "frontend"
if frontend_dir.exists():
    app.mount("/", StaticFiles(directory=str(frontend_dir), html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "backend.app:app",
        host=config.get("host", "127.0.0.1"),
        port=int(config.get("port", 8000)),
        reload=False,
        log_level="info",
    )
