#!/bin/bash

echo ""
echo "========================================"
echo "  MikroTik Card Analyzer v2.0"
echo "========================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python3 is not installed"
    echo "Please install Python 3.9 or higher"
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "[INFO] Creating virtual environment..."
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to create virtual environment"
        exit 1
    fi
fi

# Activate virtual environment
source venv/bin/activate

# Install requirements if needed
if ! python -c "import fastapi" &> /dev/null; then
    echo "[INFO] Installing requirements..."
    pip install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to install requirements"
        exit 1
    fi
fi

echo "[INFO] Starting server..."
echo ""
echo "Server will be available at: http://127.0.0.1:8000"
echo "Press Ctrl+C to stop the server"
echo ""

# Start the application
python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000 --reload
