import {api} from "./api.js";
import {dashboard} from "./components/dashboard.js";
import {showImport} from "./components/import.js";
import {showAnalysis} from "./components/analysis.js";
import {showGenerator} from "./components/generator.js";
import {showInspector} from "./components/inspector.js";
import {showAuthLab} from "./components/authlab.js";
import {showReports} from "./components/reports.js";
import {showSettings} from "./components/settings.js";
const view=document.querySelector("#view");
const pages={dashboard,import:showImport,analysis:showAnalysis,generator:showGenerator,
 inspector:showInspector,authlab:showAuthLab,reports:showReports,settings:showSettings};
const nav=document.querySelector("#nav");
Object.keys(pages).forEach(key=>{const b=document.createElement("button");b.textContent=key;b.onclick=()=>pages[key](view,api);nav.append(b)});
dashboard(view,api);
