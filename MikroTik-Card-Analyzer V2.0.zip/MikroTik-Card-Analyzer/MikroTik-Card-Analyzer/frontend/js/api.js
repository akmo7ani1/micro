/**
 * Main application controller
 */
class App {
    constructor() {
        this.currentPage = 'dashboard';
        this.init();
    }

    init() {
        this.setupNavigation();
        this.setupGlobalHandlers();
        this.loadPage('dashboard');
    }

    setupNavigation() {
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.dataset.page;
                this.navigateTo(page);
            });
        });
    }

    setupGlobalHandlers() {
        // Refresh button
        document.getElementById('refresh-btn').addEventListener('click', () => {
            this.loadPage(this.currentPage);
        });
    }

    navigateTo(page) {
        // Update nav
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.page === page);
        });

        // Update page
        document.querySelectorAll('.page').forEach(p => {
            p.classList.toggle('active', p.id === `page-${page}`);
        });

        // Update title
        const titles = {
            dashboard: 'لوحة التحكم',
            import: 'استيراد الكروت',
            analysis: 'تحليل الأنماط',
            generator: 'المولد الاصطناعي',
            inspector: 'فحص صفحات الدخول',
            authlab: 'مختبر المصادقة',
            reports: 'التقارير',
            settings: 'الإعدادات',
        };
        document.getElementById('page-title').textContent = titles[page] || page;

        this.currentPage = page;
        this.loadPage(page);
    }

    async loadPage(page) {
        try {
            switch (page) {
                case 'dashboard':
                    await DashboardPage.load();
                    break;
                case 'import':
                    await ImportPage.load();
                    break;
                case 'analysis':
                    await AnalysisPage.load();
                    break;
                case 'generator':
                    await GeneratorPage.load();
                    break;
                case 'inspector':
                    await InspectorPage.load();
                    break;
                case 'authlab':
                    await AuthLabPage.load();
                    break;
                case 'reports':
                    await ReportsPage.load();
                    break;
                case 'settings':
                    await SettingsPage.load();
                    break;
            }
        } catch (error) {
            console.error(`Error loading ${page}:`, error);
            Toast.show(`خطأ في تحميل الصفحة: ${error.message}`, 'error');
        }
    }
}

/**
 * Toast notification system
 */
class Toast {
    static show(message, type = 'info', duration = 3000) {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;

        container.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'slideIn 0.3s reverse';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    window.app = new App();
});
