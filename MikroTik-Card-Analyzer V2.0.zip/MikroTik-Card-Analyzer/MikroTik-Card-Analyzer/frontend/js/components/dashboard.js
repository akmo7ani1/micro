/**
 * Dashboard page controller
 */
class DashboardPage {
    static async load() {
        await this.loadStats();
        await this.loadCharts();
        await this.loadActivity();
    }

    static async loadStats() {
        try {
            const stats = await api.getCardStats();
            document.getElementById('stat-total-cards').textContent = stats.total_cards || 0;
            document.getElementById('stat-cards-with-password').textContent = stats.cards_with_password || 0;
            document.getElementById('stat-total-batches').textContent = stats.total_batches || 0;

            // Load test session count
            const sessions = await api.getSessions(1, 1);
            document.getElementById('stat-total-tests').textContent = sessions.total || 0;
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }

    static async loadCharts() {
        try {
            const analysis = await api.analyzePatterns();
            
            if (analysis.data && analysis.data.username_analysis) {
                const lengthDist = analysis.data.username_analysis.length_distribution || {};
                const labels = Object.keys(lengthDist).sort((a, b) => a - b);
                const data = labels.map(l => lengthDist[l]);
                
                chartManager.createBarChart(
                    'username-length-chart',
                    labels,
                    data,
                    'عدد الكروت'
                );
            }

            if (analysis.data && analysis.data.pattern_analysis) {
                const patterns = analysis.data.pattern_analysis.detected_patterns || {};
                const labels = Object.keys(patterns);
                const data = labels.map(p => patterns[p].count);
                
                chartManager.createPieChart(
                    'patterns-chart',
                    labels,
                    data,
                    'الأنماط'
                );
            }
        } catch (error) {
            console.error('Error loading charts:', error);
        }
    }

    static async loadActivity() {
        try {
            const logs = await api.getActivityLogs(1, 10);
            const container = document.getElementById('activity-list');

            if (logs.logs && logs.logs.length > 0) {
                container.innerHTML = logs.logs.map(log => `
                    <div class="activity-item">
                        <div>${log.action} - ${log.target || ''}</div>
                        <div class="time">${new Date(log.created_at).toLocaleString('ar')}</div>
                    </div>
                `).join('');
            } else {
                container.innerHTML = '<p class="empty-state">لا يوجد نشاط حديث</p>';
            }
        } catch (error) {
            console.error('Error loading activity:', error);
        }
    }
}