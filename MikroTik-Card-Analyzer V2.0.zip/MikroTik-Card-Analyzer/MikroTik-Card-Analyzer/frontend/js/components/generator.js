/**
 * Generator page controller
 */
class GeneratorPage {
    static async load() {
        this.setupForm();
        this.setupExportButton();
    }

    static setupForm() {
        document.getElementById('generator-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.generate();
        });
    }

    static setupExportButton() {
        document.getElementById('export-generated-btn').addEventListener('click', () => {
            this.exportGenerated();
        });
    }

    static async generate() {
        const params = {
            count: parseInt(document.getElementById('gen-count').value),
            username_length: parseInt(document.getElementById('gen-username-length').value),
            password_length: parseInt(document.getElementById('gen-password-length').value),
            prefix: document.getElementById('gen-prefix').value,
            suffix: document.getElementById('gen-suffix').value,
            seed: document.getElementById('gen-seed').value ? 
                  parseInt(document.getElementById('gen-seed').value) : null,
        };

        try {
            const result = await api.generateCredentials(params);
            this.displayGenerated(result.credentials);
            Toast.show(`تم توليد ${result.count} كرت`, 'success');
        } catch (error) {
            Toast.show(`خطأ في التوليد: ${error.message}`, 'error');
        }
    }

    static displayGenerated(credentials) {
        const tbody = document.getElementById('generated-tbody');
        
        if (credentials && credentials.length > 0) {
            tbody.innerHTML = credentials.map((cred, idx) => `
                <tr>
                    <td>${idx + 1}</td>
                    <td>${cred.username}</td>
                    <td>${cred.password || '-'}</td>
                </tr>
            `).join('');
        } else {
            tbody.innerHTML = '<tr><td colspan="3" class="empty-state">لم يتم توليد بيانات</td></tr>';
        }
    }

    static exportGenerated() {
        const rows = document.querySelectorAll('#generated-tbody tr');
        if (rows.length === 0 || rows[0].querySelector('.empty-state')) {
            Toast.show('لا توجد بيانات للتصدير', 'error');
            return;
        }

        let csv = 'Index,Username,Password\n';
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            csv += `${cells[0].textContent},${cells[1].textContent},${cells[2].textContent}\n`;
        });

        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `generated_credentials_${Date.now()}.csv`;
        link.click();

        Toast.show('تم التصدير بنجاح', 'success');
    }
}