/**
 * Import page controller
 */
class ImportPage {
    static async load() {
        this.setupUpload();
        this.setupCleanButton();
        await this.loadBatches();
    }

    static setupUpload() {
        const uploadZone = document.getElementById('upload-zone');
        const fileInput = document.getElementById('file-input');

        uploadZone.addEventListener('click', () => fileInput.click());

        uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadZone.style.borderColor = '#38bdf8';
        });

        uploadZone.addEventListener('dragleave', () => {
            uploadZone.style.borderColor = '#475569';
        });

        uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadZone.style.borderColor = '#475569';
            const files = e.dataTransfer.files;
            this.handleFiles(files);
        });

        fileInput.addEventListener('change', (e) => {
            this.handleFiles(e.target.files);
        });
    }

    static async handleFiles(files) {
        for (const file of files) {
            await this.uploadFile(file);
        }
    }

    static async uploadFile(file) {
        const progress = document.getElementById('upload-progress');
        const progressFill = progress.querySelector('.progress-fill');
        const progressText = progress.querySelector('.progress-text');

        progress.style.display = 'block';
        progressFill.style.width = '0%';
        progressText.textContent = `جاري رفع ${file.name}...`;

        try {
            progressFill.style.width = '50%';
            const result = await api.importCard(file);
            progressFill.style.width = '100%';
            progressText.textContent = `تم استيراد ${result.data.imported_count} كرت بنجاح`;
            
            Toast.show(`تم استيراد ${result.data.imported_count} كرت`, 'success');
            await this.loadBatches();
        } catch (error) {
            progressText.textContent = `خطأ: ${error.message}`;
            Toast.show(`فشل الاستيراد: ${error.message}`, 'error');
        }

        setTimeout(() => {
            progress.style.display = 'none';
        }, 3000);
    }

    static setupCleanButton() {
        document.getElementById('clean-data-btn').addEventListener('click', async () => {
            try {
                const result = await api.cleanData();
                Toast.show('تم تنظيف البيانات بنجاح', 'success');
                await this.loadBatches();
            } catch (error) {
                Toast.show(`خطأ في التنظيف: ${error.message}`, 'error');
            }
        });
    }

    static async loadBatches() {
        try {
            const result = await api.getBatches();
            const tbody = document.getElementById('batches-tbody');

            if (result.batches && result.batches.length > 0) {
                tbody.innerHTML = result.batches.map(batch => `
                    <tr>
                        <td>${batch.batch_id}</td>
                        <td>${batch.source_file}</td>
                        <td>${batch.card_count}</td>
                        <td>${new Date(batch.imported_at).toLocaleString('ar')}</td>
                        <td>
                            <button class="btn btn-secondary" onclick="ImportPage.deleteBatch('${batch.batch_id}')">حذف</button>
                        </td>
                    </tr>
                `).join('');
            } else {
                tbody.innerHTML = '<tr><td colspan="5" class="empty-state">لا توجد دفعات</td></tr>';
            }
        } catch (error) {
            console.error('Error loading batches:', error);
        }
    }

    static async deleteBatch(batchId) {
        if (!confirm('هل أنت متأكد من حذف هذه الدفعة؟')) return;

        try {
            await api.deleteBatch(batchId);
            Toast.show('تم حذف الدفعة', 'success');
            await this.loadBatches();
        } catch (error) {
            Toast.show(`خطأ في الحذف: ${error.message}`, 'error');
        }
    }
}