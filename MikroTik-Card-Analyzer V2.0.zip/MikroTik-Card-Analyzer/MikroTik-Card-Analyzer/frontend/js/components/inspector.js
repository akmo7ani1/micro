/**
 * Inspector page controller
 */
class InspectorPage {
    static async load() {
        this.setupForm();
    }

    static setupForm() {
        document.getElementById('inspector-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.inspect();
        });
    }

    static async inspect() {
        const url = document.getElementById('inspect-url').value;

        try {
            const result = await api.inspectPage(url);
            
            if (result.success && result.data) {
                this.displayResults(result.data);
                Toast.show('تم الفحص بنجاح', 'success');
            }
        } catch (error) {
            Toast.show(`خطأ في الفحص: ${error.message}`, 'error');
        }
    }

    static displayResults(data) {
        document.getElementById('inspection-results').style.display = 'block';

        // Auth mode
        const authMode = document.getElementById('inspect-auth-mode');
        authMode.textContent = data.auth_mode;
        authMode.className = 'badge badge-info';

        // Fields count
        const totalFields = data.forms.reduce((sum, form) => sum + form.inputs.length, 0);
        document.getElementById('inspect-fields-count').textContent = totalFields;

        // JavaScript
        document.getElementById('inspect-has-js').textContent = data.has_javascript ? 'نعم' : 'لا';

        // Form details
        const detailsContainer = document.getElementById('inspect-form-details');
        if (data.forms.length > 0) {
            detailsContainer.innerHTML = data.forms.map((form, idx) => `
                <div class="form-detail-item">
                    <h5>النموذج ${idx + 1}</h5>
                    <p><strong>Action:</strong> ${form.action || 'N/A'}</p>
                    <p><strong>Method:</strong> ${form.method}</p>
                    <p><strong>الحقول:</strong></p>
                    <ul>
                        ${form.inputs.map(inp => `
                            <li>${inp.name || 'unnamed'} (${inp.type})</li>
                        `).join('')}
                    </ul>
                </div>
            `).join('');
        } else {
            detailsContainer.innerHTML = '<p>لم يتم العثور على نماذج</p>';
        }
    }
}