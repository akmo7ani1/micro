/**
 * Analysis page controller
 */
class AnalysisPage {
    static async load() {
        this.setupAnalyzeButton();
    }

    static setupAnalyzeButton() {
        document.getElementById('analyze-btn').addEventListener('click', async () => {
            await this.runAnalysis();
        });
    }

    static async runAnalysis() {
        const btn = document.getElementById('analyze-btn');
        btn.disabled = true;
        btn.textContent = 'جاري التحليل...';

        try {
            const result = await api.analyzePatterns();
            
            if (result.data && !result.data.error) {
                this.displayResults(result.data);
                Toast.show('تم التحليل بنجاح', 'success');
            } else {
                Toast.show(result.data?.message || 'لا توجد بيانات للتحليل', 'error');
            }
        } catch (error) {
            Toast.show(`خطأ في التحليل: ${error.message}`, 'error');
        } finally {
            btn.disabled = false;
            btn.textContent = 'بدء التحليل';
        }
    }

    static displayResults(data) {
        document.getElementById('analysis-results').style.display = 'block';

        // Stats
        if (data.username_analysis && data.username_analysis.length_stats) {
            const stats = data.username_analysis.length_stats;
            document.getElementById('analysis-min-length').textContent = stats.min;
            document.getElementById('analysis-max-length').textContent = stats.max;
            document.getElementById('analysis-avg-length').textContent = stats.avg.toFixed(2);
        }

        if (data.pattern_analysis && data.pattern_analysis.most_common_pattern) {
            document.getElementById('analysis-common-pattern').textContent = 
                data.pattern_analysis.most_common_pattern;
        }

        // Charts
        if (data.username_analysis && data.username_analysis.common_prefixes) {
            const prefixes = data.username_analysis.common_prefixes;
            const labels = Object.keys(prefixes).slice(0, 10);
            const values = labels.map(l => prefixes[l]);

            chartManager.createBarChart('prefixes-chart', labels, values, 'العدد');
        }

        if (data.pattern_analysis && data.pattern_analysis.detected_patterns) {
            const patterns = data.pattern_analysis.detected_patterns;
            const labels = Object.keys(patterns);
            const values = labels.map(p => patterns[p].count);

            chartManager.createPieChart('pattern-distribution-chart', labels, values, 'الأنماط');
        }
    }
}