/**
 * Auth Lab page controller
 */
class AuthLabPage {
    static async load() {
        this.setupTestForm();
        this.setupClearButton();
        await this.loadSessions();
    }

    static setupTestForm() {
        document.getElementById('auth-test-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.testAuth();
        });
    }

    static setupClearButton() {
        document.getElementById('clear-sessions-btn').addEventListener('click', async () => {
            if (!confirm('هل أنت متأكد من مسح جميع السجلات؟')) return;
            
            try {
                await api.clearSessions();
                Toast.show('تم مسح السجلات', 'success');
                await this.loadSessions();
            } catch (error) {
                Toast.show(`خطأ: ${error.message}`, 'error');
            }
        });
    }

    static async testAuth() {
        const params = {
            target_url: document.getElementById('test-target-url').value,
            username: document.getElementById('test-username').value,
            password: document.getElementById('test-password').value || null,
            auth_mode: document.getElementById('test-auth-mode').value,
        };

        try {
            const result = await api.testAuth(params);
            
            if (result.success && result.result) {
                const status = result.result.success ? 'نجاح' : 'فشل';
                Toast.show(`نتيجة الاختبار: ${status}`, result.result.success ? 'success' : 'error');
                await this.loadSessions();
            }
        } catch (error) {
            Toast.show(`خطأ في الاختبار: ${error.message}`, 'error');
        }
    }

    static async loadSessions() {
        try {
            const result = await api.getSessions();
            const tbody = document.getElementById('sessions-tbody');

            if (result.sessions && result.sessions.length > 0) {
                tbody.innerHTML = result.sessions.map(session => `
                    <tr>
                        <td>${new Date(session.created_at).toLocaleString('ar')}</td>
                        <td>${session.username}</td>
                        <td>${session.auth_mode}</td>
                        <td>
                            <span class="badge ${session.success ? 'badge-success' : 'badge-error'}">
                                ${session.success ? 'نجاح' : 'فشل'}
                            </span>
                        </td>
                        <td>${session.response_time_ms ? session.response_time_ms.toFixed(0) + ' ms' : '-'}</td>
                    </tr>
                `).join('');
            } else {
                tbody.innerHTML = '<tr><td colspan="5" class="empty-state">لا توجد اختبارات</td></tr>';
            }
        } catch (error) {
            console.error('Error loading sessions:', error);
        }
    }
}