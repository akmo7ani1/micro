/**
 * Reports page controller
 */
class ReportsPage {
    static async load() {
        this.setupExportButtons();
        await this.loadHistory();
    }

    static setupExportButtons() {
        document.querySelectorAll('[data-export]').forEach(btn => {
            btn.addEventListener('click', () => {
                this.export(btn.dataset.export);
            });
        });
    }

    static async export(type) {
        const endpoints = {
            'cards-csv': '/api/reports/export/cards/csv',
            'cards-excel': '/api/reports/export/cards/excel',
            'cards-json': '/api/reports/export/cards/json',
            'analysis-pdf': '/api/reports/export/analysis/pdf',
            'analysis-excel': '/api/reports/export/analysis/excel',
            'sessions-csv': '/api/reports/export/sessions/csv',
        };

        const endpoint = endpoints[type];
        if (!endpoint) return;

        try {
            const response = await fetch(`http://localhost:8000${endpoint}`);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const blob = await response.blob();
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `report_${type}_${Date.now()}`;
            a.click();
            URL.revokeObjectURL(url);

            Toast.show('تم التصدير بنجاح', 'success');
            await this.loadHistory();
        } catch (error) {
            Toast.show(`خطأ في التصدير: ${error.message}`, 'error');
        }
    }

    static async loadHistory() {
        try {
            const result = await api.getExportHistory();
            const tbody = document.getElementById('export-history-tbody');

            if (result.files && result.files.length > 0) {
                tbody.innerHTML = result.files.map(file => `
                    <tr>
                        <td>${file.filename}</td>
                        <td>${(file.size_bytes / 1024).toFixed(2)} KB</td>
                        <td>${new Date(file.created_at).toLocaleString('ar')}</td>
                    </tr>
                `).join('');
            } else {
                tbody.innerHTML = '<tr><td colspan="3" class="empty-state">لا توجد ملفات مصدرة</td></tr>';
            }
        } catch (error) {
            console.error('Error loading history:', error);
        }
    }
}