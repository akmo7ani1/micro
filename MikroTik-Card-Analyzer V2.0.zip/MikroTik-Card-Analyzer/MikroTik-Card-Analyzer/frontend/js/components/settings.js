/**
 * Settings page controller
 */
class SettingsPage {
    static async load() {
        await this.loadSettings();
        await this.loadSystemInfo();
    }

    static async loadSettings() {
        try {
            const result = await api.getSettings();
            const container = document.getElementById('settings-container');

            if (result.settings) {
                container.innerHTML = `
                    <div class="info-list">
                        <div class="info-row">
                            <span class="label">اسم التطبيق:</span>
                            <span>${result.settings.app_name}</span>
                        </div>
                        <div class="info-row">
                            <span class="label">الإصدار:</span>
                            <span>${result.settings.version}</span>
                        </div>
                        <div class="info-row">
                            <span class="label">المنفذ:</span>
                            <span>${result.settings.port}</span>
                        </div>
                        <div class="info-row">
                            <span class="label">اللغة الافتراضية:</span>
                            <span>${result.settings.ui.default_language}</span>
                        </div>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error loading settings:', error);
        }
    }

    static async loadSystemInfo() {
        try {
            const result = await api.getSystemInfo();
            const container = document.getElementById('system-info');

            container.innerHTML = `
                <div class="info-row">
                    <span class="label">إصدار Python:</span>
                    <span>${result.python_version}</span>
                </div>
                <div class="info-row">
                    <span class="label">النظام:</span>
                    <span>${result.platform}</span>
                </div>
                <div class="info-row">
                    <span class="label">مسار قاعدة البيانات:</span>
                    <span>${result.database_path}</span>
                </div>
                <div class="info-row">
                    <span class="label">مجلد التصدير:</span>
                    <span>${result.exports_directory}</span>
                </div>
            `;
        } catch (error) {
            console.error('Error loading system info:', error);
        }
    }
}